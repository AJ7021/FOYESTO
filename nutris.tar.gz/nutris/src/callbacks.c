#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include <string.h>
#include <stdio.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include"treeview.h"
#include"function.h"

void
on_AcceuilGestion_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *p;
GtkWidget *p1;
GtkWidget *entry;
GtkWidget *entry2;
GtkWidget *labelid;
GtkWidget *labeldate;
gtk_widget_hide (acceuil);
gestion = create_gestion ();
p=lookup_widget(gestion,"treeview1");
p1=lookup_widget(gestion,"treeview2");
i=0;
j=0;
k=0;
AfficherMenu(p,"Menu.txt");
AfficherMenu1(p1,"Menu.txt");
gtk_widget_show (gestion);

entry=lookup_widget(gestion,"entry_idc");
gtk_widget_hide (entry);
entry2=lookup_widget(gestion,"entry_datec");
gtk_widget_hide (entry2);
labelid=lookup_widget(gestion,"label_idc");
gtk_widget_hide (labelid);
labeldate=lookup_widget(gestion,"label_datec");
gtk_widget_hide (labeldate);
}


void
on_GestionAcceuil_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show (acceuil);
gtk_widget_destroy (gestion);
}


void
on_Ajouter_Menu_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
Menu M;
GtkWidget *existe;
GtkWidget *succes;
GtkWidget *combobox;
GtkWidget *spin;
int a;

existe=lookup_widget(gestion,"label_existant");
succes=lookup_widget(gestion,"label_succes1");
int aa,jj,mm;

strcpy(M.id,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestion,"entry_id"))));
strcpy(M.entree,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestion,"entry_entree"))));
strcpy(M.dessert,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestion,"entry_dessert"))));
if(gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(lookup_widget(gestion,"radiobutton1")) )){
strcpy(M.salade,"Cesar");}
if(gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(lookup_widget(gestion,"radiobutton2")) )){
strcpy(M.salade,"Mechouia");}
if(gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(lookup_widget(gestion,"radiobutton3")) )){
strcpy(M.salade,"Tunisienne");}
strcpy(M.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(lookup_widget(gestion,"combobox1"))));

spin = lookup_widget(gestion,"spinbutton1");

a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin));

sprintf(M.date,"%d",a);


if(exist_menu(M.id)==1)
        {

				  gtk_widget_show (existe);
        }
        else {
						  gtk_widget_hide (existe);
                ajouter_menu(M);

						  gtk_widget_show (succes);
		
	GtkWidget* p=lookup_widget(gestion,"treeview1");

        AfficherMenu(p,"Menu.txt");
        }
}


void
on_Modifier_Menu_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
	Menu M;

        strcpy(M.id,gtk_label_get_text(GTK_LABEL(lookup_widget(gestion,"label_id3"))));
        strcpy(M.entree,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestion,"entry_entree2"))));
	strcpy(M.salade,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestion,"entry_salade2"))));
        strcpy(M.dessert,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestion,"entry_dessert2"))));
	strcpy(M.type,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestion,"entry_type2"))));
	strcpy(M.date,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestion,"entry_date2"))));
	
        

        supprimer_menu(M.id);
        ajouter_menu(M);
	 
        AfficherMenu(lookup_widget(gestion,"treeview1"),"Menu.txt");
		gtk_widget_show(lookup_widget(gestion,"label_succes2"));

}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	gchar *id;
        gchar *entree;
        gchar *salade;
        gchar *dessert;
        gchar *type;
	gchar *date;
        int x;
        GtkTreeModel     *model;
        GtkTreeIter iter;
        GtkWidget *p=lookup_widget(gestion,"treeview1");
        GtkTreeSelection *selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {
		gtk_widget_hide(lookup_widget(gestion,"label_succes2"));
		
                gtk_tree_model_get (model,&iter,0,&id,1,&entree,2,&salade,3,&dessert,4,&type,5,&date,-1); 
		
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(gestion,"entry_id2")),id);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(gestion,"entry_entree2")),entree);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(gestion,"entry_salade2")),salade);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(gestion,"entry_dessert2")),dessert);



                GtkWidget* msgID=lookup_widget(gestion,"label_id3");
                GtkWidget* msg1=lookup_widget(gestion,"label_modifier");
                gtk_label_set_text(GTK_LABEL(msgID),id);
                gtk_widget_show(msgID);
                gtk_widget_show(msg1);
                gtk_widget_show(lookup_widget(gestion,"Modifier"));
                gtk_notebook_prev_page(GTK_NOTEBOOK(lookup_widget(gestion,"notebook1")));
        }

}


void
on_Supprimer_Menu_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkTreeModel     *model;
        GtkTreeSelection *selection;
        GtkTreeIter iter;
        GtkWidget* p;
        GtkWidget *label;
        gchar* id;
        label=lookup_widget(gestion,"label_selectionner");
        p=lookup_widget(gestion,"treeview1");




        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {  gtk_tree_model_get (model,&iter,0,&id,-1);
           gtk_list_store_remove(GTK_LIST_STORE(model),&iter);

           supprimer_menu(id);

           gtk_widget_hide (label);}
	else{
                gtk_widget_show (label);
        }
}


void
on_Chercher_Menu_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *p1;
GtkWidget *entry;
GtkWidget *entry2;
GtkWidget *labeldate;
GtkWidget *labelid;
GtkWidget *nbResultat;
GtkWidget *message;
char id[50];
char date[50];
char chnb[30];
int nb;
int xm=0,xn=0;
entry=lookup_widget(gestion,"entry_idc");
labelid=lookup_widget(gestion,"label_idc");
p1=lookup_widget(gestion,"treeview2");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(entry)));

entry2=lookup_widget(gestion,"entry_datec");
labelid=lookup_widget(gestion,"label_datec");
p1=lookup_widget(gestion,"treeview2");
strcpy(date,gtk_entry_get_text(GTK_ENTRY(entry2)));

if(gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(lookup_widget(gestion,"checkbutton1")) )){
xm=1;}
if(gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(lookup_widget(gestion,"checkbutton2")) )){
xn=1;}



nb=ChercherMenu(p1,"Menu.txt",id,date,xm,xn);

sprintf(chnb,"%d",nb);
nbResultat=lookup_widget(gestion,"label_nb");
message=lookup_widget(gestion,"label_resultat");
gtk_label_set_text(GTK_LABEL(nbResultat),chnb);

gtk_widget_show (nbResultat);
gtk_widget_show (message);

}






void
on_radiobutton1_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
//if(gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(lookup_widget(gestion,"radiobutton1")) )){
//strcpy(M.salade,"Cesar");}
}


void
on_radiobutton2_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
//if(gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(lookup_widget(gestion,"radiobutton2")) )){
//strcpy(M.salade,"Mechouia");}
}


void
on_radiobutton3_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
//if(gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(lookup_widget(gestion,"radiobutton3")) )){
//strcpy(M.salade,"Tunisienne");}
}


void
on_radiobutton4_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
//if(gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(lookup_widget(gestion,"radiobutton4")) )){
//strcpy(M.salade,"Cesar");}
}


void
on_radiobutton5_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
//if(gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(lookup_widget(gestion,"radiobutton5")) )){
//strcpy(M.salade,"Mechouia");}
}


void
on_radiobutton6_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
//if(gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(lookup_widget(gestion,"radiobutton6")) )){
//strcpy(M.salade,"Tunisienne");}
}


void
on_checkbutton1_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *entry;
GtkWidget *labelid;
entry=lookup_widget(gestion,"entry_idc");
labelid=lookup_widget(gestion,"label_idc");

if(gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(lookup_widget(gestion,"checkbutton1")) )){
gtk_widget_show (entry);
gtk_widget_show (labelid);}

else{gtk_widget_hide (entry);
gtk_widget_hide (labelid);}
}


void
on_checkbutton2_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *entry2;
GtkWidget *labeldate;
entry2=lookup_widget(gestion,"entry_datec");
labeldate=lookup_widget(gestion,"label_datec");

if(gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(lookup_widget(gestion,"checkbutton2")) )){
gtk_widget_show (entry2);
gtk_widget_show (labeldate);}

else{gtk_widget_hide (entry2);
gtk_widget_hide (labeldate);}
}


void
on_button_meilleur_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
FILE* f;
FILE* fm;
int a,b,na,nb;
float c,nc=1000.00;
  int l;
    char id[50];
    char date[50];
    char type[50];
    char entree[50];
    char salade[50];
    char dessert[50];
   
char text[15];
char msg[100]="le meilleur menu est ";
GtkWidget *sortie;
sortie=lookup_widget(gestion,"label_meilleur");
f=fopen("dechets.txt","r");
while(fscanf(f,"%d %d %f\n",&a,&b,&c)!=EOF){

  if (nc>c){nc=c;
  nb=b;
  na=a;                 }
}
sprintf(text,"%d",na);
fm=fopen("Menu.txt","r");

while(fscanf(fm,"%s %s %s %s %s %s\n",id,entree,salade,dessert,type,date)!=EOF){
   



if (strcmp(type,"Petit_dej")==0){l=1;}
else if (strcmp(type,"Dejeuner")==0){l=2;}
else if (strcmp(type,"Dinner")==0){l=3;}




if ((strcmp(date,text)==0) && (nb==l)){ 

strcat(msg,id);
 gtk_label_set_text(GTK_LABEL(sortie),msg);
}
}
fclose(fm);
fclose(f);
}


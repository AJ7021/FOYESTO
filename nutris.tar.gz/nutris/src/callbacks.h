#include <gtk/gtk.h>
  GtkWidget *acceuil;
  GtkWidget *gestion;
typedef struct Menu Menu;
struct Menu {
    char id[50];
    char date[50];
    char type[50];
    char entree[50];
    char salade[50];
    char dessert[50];


};

int i,j,k;

void
on_AcceuilGestion_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_GestionAcceuil_clicked              (GtkButton       *button,
                                        gpointer         user_data);



void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);


void
on_button_meilleur_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_Ajouter_Menu_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_Modifier_Menu_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_Supprimer_Menu_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_Chercher_Menu_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_meilleur_menu_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton2_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton3_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton4_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton5_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton6_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton1_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton2_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_meilleur_clicked             (GtkButton       *button,
                                        gpointer         user_data);

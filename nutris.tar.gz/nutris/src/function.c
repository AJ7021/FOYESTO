#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include "callbacks.h"
#include<string.h>


void ajouter_menu(Menu M){
FILE*f=NULL;
f=fopen("Menu.txt","a+");
fprintf(f,"%s %s %s %s %s %s\n",M.id,M.entree,M.salade,M.dessert,M.type,M.date);
fclose(f);

}

int exist_menu(char*id){
FILE*f=NULL;
 Menu M;
f=fopen("Menu.txt","r");
while(fscanf(f,"%s %s %s %s %s %s\n",M.id,M.entree,M.salade,M.dessert,M.type,M.date)!=EOF){
if(strcmp(M.id,id)==0)return 1;
}
fclose(f);
return 0;
}


void supprimer_menu(char*id){
FILE*f=NULL;
FILE*f1=NULL;
Menu M ;
f=fopen("Menu.txt","r");

f1=fopen("tmp.txt","w+");//
while(fscanf(f,"%s %s %s %s %s %s\n",M.id,M.entree,M.salade,M.dessert,M.type,M.date)!=EOF){
if(strcmp(id,M.id)!=0)fprintf(f1,"%s %s %s %s %s %s\n",M.id,M.entree,M.salade,M.dessert,M.type,M.date);
}
fclose(f);
fclose(f1);
remove("Menu.txt");
rename("tmp.txt","Menu.txt");
}





















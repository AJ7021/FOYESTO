

void AfficherMenu(GtkWidget* treeview1,char*l);
void AfficherMenu1(GtkWidget* treeview1,char*l);
int ChercherMenu(GtkWidget* treeview1,char*l,char*id,char*date,int xm,int xn);

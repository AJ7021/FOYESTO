#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "stok.h"
char ref[50];
int toggle;



void
on_radiobutton1_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
	toggle=1;
}

}


void
on_radiobutton2_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
	toggle=2;
}
}
void
on_ajout_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
stock S;
GtkWidget *nom,*type,*reference,*quantite,*jour,*mois,*annee,*error;
nom=lookup_widget(button,"nom");
if (toggle==1)
{strcpy(S.type,"Biologique");}
else
strcpy(S.type,"Industriel");
reference=lookup_widget(button,"ref");
quantite=lookup_widget(button,"quant");
jour=lookup_widget(button,"Jourd");
mois=lookup_widget(button,"moisd");
annee=lookup_widget(button,"anneed");
strcpy(S.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(S.reference,gtk_entry_get_text(GTK_ENTRY(reference)));
S.quantite=atoi(gtk_entry_get_text(GTK_ENTRY(quantite)));
S.d.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
S.d.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
S.d.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
error=lookup_widget(button,"add");
ajouter(S);
gtk_label_set_text(GTK_LABEL(error),"Ajout avec succés");
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}
void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_chercher_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
char ref[50];
GtkWidget *treeview,*filter,*message;
treeview=lookup_widget(button,"treeview1");
filter=lookup_widget(button,"refch");
strcpy(ref,gtk_entry_get_text(GTK_ENTRY(filter)));
chercher(treeview,ref);
message=lookup_widget(button,"search");
gtk_label_set_text(GTK_LABEL(message),"Voila le produit souhaitee!");

}


void
on_supprimer_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
stock x;
GtkWidget *reference,*label1;

reference=lookup_widget(button,"refch");
strcpy(x.reference,gtk_entry_get_text(GTK_ENTRY(reference)));
label1=lookup_widget(button,"delete");
supprimer(x.reference);
gtk_label_set_text(GTK_LABEL(label1),"SUPPRESSION AVEC SUCCES!");
}


void
on_modifier_clicked                (GtkButton       *button,
                                        gpointer         user_data)
	{
stock x;
char ref[50];

GtkWidget *nom,*type,*reference,*quantite,*jour,*mois,*annee,*label,*filter;

nom=lookup_widget(button,"nom2");
type=lookup_widget(button,"combobox1");
reference=lookup_widget(button,"ref2");
quantite=lookup_widget(button,"quant2");
jour=lookup_widget(button,"jour2");
mois=lookup_widget(button,"mois2");
annee=lookup_widget(button,"annee2");
label=lookup_widget(button,"edit");
filter=lookup_widget(button,"refch");
strcpy(ref,gtk_entry_get_text(GTK_ENTRY(filter)));
strcpy(x.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(x.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type)));
strcpy(x.reference,gtk_entry_get_text(GTK_ENTRY(reference)));
x.quantite=atoi(gtk_entry_get_text(GTK_ENTRY(quantite)));
x.d.jour=atoi(gtk_entry_get_text(GTK_ENTRY(jour)));
x.d.mois=atoi(gtk_entry_get_text(GTK_ENTRY(mois)));
x.d.annee=atoi(gtk_entry_get_text(GTK_ENTRY(annee)));
modifier(ref,x.nom,x.type,x.reference,x.quantite,x.d.jour,x.d.mois,x.d.annee);
label=lookup_widget(button,"edit");
gtk_label_set_text(GTK_LABEL(label),"modification faite avec succés");

}


void
on_actualiser_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview2;
GtkWidget *stock;
treeview2=lookup_widget(button,"treeview2");
PERDS(treeview2);
}


void
on_afficher_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview1;
GtkWidget *stock;
treeview1=lookup_widget(button,"treeview1");
afficher(treeview1);
}



int veriff(char CIN1[],char password1[]);
int veriff1(char NUM1[],char password12[]);
/*
void vider1();
void afficher1();
*/

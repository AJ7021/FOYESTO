
#include"fonction.h"
#include<stdio.h>
#include <gtk/gtk.h>
#include<string.h>
enum
{
   ECIN,
   ENOM,
   EPRENOM,
   EPASSWORD,
   EADRESSE,
   EMAIL,
   ENUMERO,
 	EJOURa,
	EMOISa,
	EANNEa,
	EROLEa,
   COLUMNS
};


void participentSE_save(participentSE p)
{
FILE*f;
/*
p.role=Role;

if(f!=NULL)
{
while(fscanf(f,"%s",p.num)!=EOF)
{
if ( p.num[0]==Role)
{
*/
f=fopen("date.txt","a+");

if (f!=NULL)
{
fprintf(f,"%d %d %d \n",p.jour,p.mois,p.anne);
}
fclose(f);
}
/*
}
}
}
*/
void participentSE_ajouter(participentSE p)
{
FILE*f;

f=fopen("utilisateurS.txt","a+");

if (f!=NULL)
{
fprintf(f,"%s %s %s %s %s %s %s %d %d %d %d \n",p.CIN,p.password,p.nom,p.prenom,p.adresse,p.mail,p.numero,p.jour,p.mois,p.anne,p.role);
}
fclose(f);

}
void participentSE_ajouter12345(participentSE p)
{
FILE*f;

f=fopen("sami.txt","a+");

if (f!=NULL)
{
fprintf(f,"%s \n",p.CIN);
}
fclose(f);

}

/////////////////

/*

int remplirtab (participentSE p[],int nb)
{
    char nom[20],prenom[20];
    char CIN[20];
    char password[20],mail[20];
    char numero[20];
char adresse[20];
    
    int jour,mois,anne;
int role;
    FILE* f ;
    int i=0;

    f = fopen("utilisateurS.txt", "a+");


        while (fscanf(f,"%s %s %s %s %s %s %s %d %d %d %d \n",CIN,password,nom,prenom,adresse,mail,numero,&jour,&mois,&anne,&role)!=EOF)
        {
            nb++;
   strcpy(p[i].CIN,CIN);
   strcpy(p[i].password,password);
   strcpy(p[i].nom,nom);
   strcpy(p[i].prenom,prenom);
   strcpy(p[i].adresse,adresse);
   strcpy(p[i].mail,mail);
   strcpy(p[i].numero,numero);
   strcpy(p[i].jour,jour);
   strcpy(p[i].mois,mois);
   strcpy(p[i].anne,anne);
   strcpy(p[i].role,role);
       i++;
   
        }
       

        fclose(f);
return(nb);
}

*/





////////////////

/*

int participentSE_recherche(char CIN[])
{
participentSE p[100];
CIN[100];
int nb;
int ce,i;
FILE*f;
ce=0;
nb=remplirtab (p,nb);
for (i=0;i<nb;i++)
{if (strcmp(CIN,p[i].CIN)==0)
{
ce=1;
f=fopen("date.txt", "w+");
if("f!=NULL")
{fprintf(f,"%s %s %s %s %s %s %s %d %d %d %d \n",p[i].CIN,p[i].password,p[i].nom,p[i].prenom,p[i].adresse,p[i].mail,p[i].numero,p[i].jour,p[i].mois,p[i].anne,p[i].role);}
fclose(f);
}
}

return(ce);
}


*/


enum
{
ECINaaaa,
   ENOMaaaa,
   EPRENOMaaaa,
   EPASSWORDaaaa,
   EADRESSEaaaa,
   EMAILaaaa,
   ENUMEROaaaa,
 	EJOURaaaa,
	EMOISaaaa,
	EANNEaaaa,
	EROLEaaaa,
   COLUMNSSSS
};






//////////////////

void afficherSE2(GtkWidget *liste,char CIN[])
{

participentSE p;


GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;
    GtkTreeIter iter;
    GtkListStore *store;

    	
    	char password[30];
    	char nom[30];
   	char prenom[30];
   	char adresse[30];
 	char mail[30];
	char numero[30];
int jour;
    	int mois;
    	int anne;
   	int role;
     store=NULL;
      FILE* f;

    store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
    renderer=gtk_cell_renderer_text_new();
    column=gtk_tree_view_column_new_with_attributes(" CIN ",renderer,"text",ECINaaaa, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

    renderer=gtk_cell_renderer_text_new();
    column=gtk_tree_view_column_new_with_attributes(" password ",renderer,"text",EPASSWORDaaaa,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

    renderer=gtk_cell_renderer_text_new();
    column=gtk_tree_view_column_new_with_attributes(" nom ",renderer,"text",ENOMaaaa,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
    renderer=gtk_cell_renderer_text_new();
    column=gtk_tree_view_column_new_with_attributes(" prenom ",renderer,"text",EPRENOMaaaa,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


    renderer=gtk_cell_renderer_text_new();
    column=gtk_tree_view_column_new_with_attributes(" adresse",renderer,"text",EADRESSEaaaa,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

    renderer=gtk_cell_renderer_text_new();
    column=gtk_tree_view_column_new_with_attributes(" mail ",renderer,"text",EMAILaaaa,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

    renderer=gtk_cell_renderer_text_new();
    column=gtk_tree_view_column_new_with_attributes(" numero ",renderer,"text",ENUMERO,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
    column=gtk_tree_view_column_new_with_attributes(" jour ",renderer,"text",EJOURaaaa, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

    renderer=gtk_cell_renderer_text_new();
    column=gtk_tree_view_column_new_with_attributes(" mois ",renderer,"text",EMOISaaaa,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

    renderer=gtk_cell_renderer_text_new();
    column=gtk_tree_view_column_new_with_attributes(" anne ",renderer,"text",EANNEaaaa,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
 
    renderer=gtk_cell_renderer_text_new();
    column=gtk_tree_view_column_new_with_attributes(" role ",renderer,"text",EROLEaaaa,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
  store=gtk_list_store_new(COLUMNSSSS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);


f = fopen("utilisateurS.txt","r");
if(f==NULL)
{
return;
}
else
{
 f=fopen("utilisateurS.txt","a+");
while (fscanf(f,"%s %s %s %s %s %s %s %d %d %d %d \n",p.CIN,p.password,p.nom,p.prenom,p.adresse,p.mail,p.numero,&p.jour,&p.mois,&p.anne,&p.role)!=EOF)
{
			if(strcmp(CIN,p.CIN)==0)
{
gtk_list_store_append (store,&iter);
gtk_list_store_set(store,&iter,ECINaaaa,p.CIN,EPASSWORDaaaa,p.password,ENOMaaaa,p.nom,EPRENOMaaaa,p.prenom,EADRESSEaaaa,p.adresse,EMAILaaaa,p.mail,ENUMEROaaaa,p.numero,EJOURaaaa,p.jour,EMOISaaaa,p.mois,EANNEaaaa,p.anne,EROLEaaaa,p.role,-1);
}
}
fclose(f);
}
gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
g_object_unref(store);
}
}

void afficherSE(GtkWidget *liste)
{

participentSE p;


GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;
    GtkTreeIter iter;
    GtkListStore *store;

    	char CIN[30];
    	char password[30];
    	char nom[30];
   	char prenom[30];
   	char adresse[30];
 	char mail[30];
	char numero[30];
int jour;
    	int mois;
    	int anne;
   	int role;
     store=NULL;
      FILE* f;

    store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
    renderer=gtk_cell_renderer_text_new();
    column=gtk_tree_view_column_new_with_attributes(" CIN ",renderer,"text",ECIN, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

    renderer=gtk_cell_renderer_text_new();
    column=gtk_tree_view_column_new_with_attributes(" password ",renderer,"text",EPASSWORD,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

    renderer=gtk_cell_renderer_text_new();
    column=gtk_tree_view_column_new_with_attributes(" nom ",renderer,"text",ENOM,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
    renderer=gtk_cell_renderer_text_new();
    column=gtk_tree_view_column_new_with_attributes(" prenom ",renderer,"text",EPRENOM,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


    renderer=gtk_cell_renderer_text_new();
    column=gtk_tree_view_column_new_with_attributes(" adresse",renderer,"text",EADRESSE,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

    renderer=gtk_cell_renderer_text_new();
    column=gtk_tree_view_column_new_with_attributes(" mail ",renderer,"text",EMAIL,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

    renderer=gtk_cell_renderer_text_new();
    column=gtk_tree_view_column_new_with_attributes(" numero ",renderer,"text",ENUMERO,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
    column=gtk_tree_view_column_new_with_attributes(" jour ",renderer,"text",EJOURa, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

    renderer=gtk_cell_renderer_text_new();
    column=gtk_tree_view_column_new_with_attributes(" mois ",renderer,"text",EMOISa,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

    renderer=gtk_cell_renderer_text_new();
    column=gtk_tree_view_column_new_with_attributes(" anne ",renderer,"text",EANNEa,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
 
    renderer=gtk_cell_renderer_text_new();
    column=gtk_tree_view_column_new_with_attributes(" role ",renderer,"text",EROLEa,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
  store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);


f = fopen("utilisateurS.txt","r");
if(f==NULL)
{
return;
}
else
{
 f=fopen("utilisateurS.txt","a+");
while (fscanf(f,"%s %s %s %s %s %s %s %d %d %d %d \n",p.CIN,p.password,p.nom,p.prenom,p.adresse,p.mail,p.numero,&p.jour,&p.mois,&p.anne,&p.role)!=EOF)
{
gtk_list_store_append (store,&iter);
gtk_list_store_set(store,&iter,ECIN,p.CIN,EPASSWORD,p.password,ENOM,p.nom,EPRENOM,p.prenom,EADRESSE,p.adresse,EMAIL,p.mail,ENUMERO,p.numero,EJOURa,p.jour,EMOISa,p.mois,EANNEa,p.anne,EROLEa,p.role,-1);
}
fclose(f);
}
gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
g_object_unref(store);
}
}
/*
 while(fscanf(f,"%s %s %s %s %s %s \n",CIN,password,nom,prenom,adresse,mail)!=EOF)
else
	{
		fp = fopen("utilisateurs.bin", "ab+");	
		while(fread(&p, sizeof(p), 1, fp))
		{
		sprintf(DATE, "%d/%d/%d", p.date_naissance.jour,p.date_naissance.mois,p.date_naissance.annee);
		
		gtk_list_store_append(store, &iter);
		gtk_list_store_set(store, &iter, NOM, p.nom, PRENOM, p.prenom, SEXE, p.sexe, DATE_NAISSANCE, DATE, CIN, p.cin, GSM, p.gsm, ID, p.id,-1);
		}
		fclose(fp);
		gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
		g_object_unref(store);
	}

*/
void participentSE_supprimer(char CIN[])
{
    participentSE p;

    FILE*f=NULL;
    FILE*f1=NULL;

    f=fopen("utilisateurS.txt","r");
    f1=fopen("utilisateurS1.txt","a+");

    
        while(fscanf(f,"%s %s %s %s %s %s %s %d %d %d %d \n",p.CIN,p.password,p.nom,p.prenom,p.adresse,p.mail,p.numero,&p.jour,&p.mois,&p.anne,&p.role)!=EOF)
        {
            if(strcmp(CIN,p.CIN)!=0)
                fprintf(f1,"%s %s %s %s %s %s %s %d %d %d %d \n",p.CIN,p.password,p.nom,p.prenom,p.adresse,p.mail,p.numero,p.jour,p.mois,p.anne,p.role);
}
        fclose(f);
        fclose(f1);
        remove("utilisateurS.txt");
        rename("utilisateurS1.txt","utilisateurS.txt");
 }

/*

void vider1(GtkWidget *liste)
{



GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char cin [30];
char nom[30];
char prenom [30];
char password[30] ;
char adresse [30];
char mail[30];
char role [30];
store =NULL;

FILE *f;

store=gtk_tree_view_get_model(liste);
if(store==NULL)
{
	renderer=gtk_cell_renderer_text_new();
	
	column=gtk_tree_view_column_new_with_attributes("cin",renderer,"text",Cin,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
	
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",Nom,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
	
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",Prenom,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
	
	
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("password",renderer,"text",Password,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
	
	

       renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("adresse",renderer,"text",Adresse,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
	
	
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("mail",renderer,"text",Mail,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
	
	
      
}

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

gtk_list_store_append(store,&iter);

gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
}




*/

void participentSE_modifier(char CIN[])

{
char ch1[20];
    participentSE p;
participentSE p1;
    FILE* f;
FILE* f1;
    FILE *f2;
f1=fopen("uti.txt","r+");
    f=fopen("utilisateurS.txt","r+");
    f2=fopen("utilisateurS1.txt","w");
     int jour111;
  int mois111;
  int anne111;
  int role12;

char ch2[20];
char ch3[20];
char ch4[20];
char ch5[20];
char ch6[20];
char ch7[20];
char ch8[20];
char ch9[20];

 

    
        if
            (strcmp(p.CIN,CIN)==0)
             
            {  
 
 fprintf(f2,"%s %s %s %s %s %s %s %d %d %d %d \n",p.CIN,p.password,p.nom,p.prenom,p.adresse,p.mail,p.numero,p.jour,p.mois,p.anne,p.role);
     
 
 }

            
else
{
 fprintf(f2,"%s %s %s %s %s %s %s %d %d %d %d \n",ch3,ch8,ch5,ch6,ch7,ch4,ch9,jour111,mois111,anne111,role12);
}


       fclose(f1);
        fclose(f);    
        fclose(f2);
        remove("utilisateurS.txt");
        rename("utilisateurS1.txt","utilisateurS.txt");
   
}










enum
{
	ECINa,
   ENOMa,
   EPRENOMa,
   EPASSWORDa,
   EADRESSEa,
   EMAILa,
   ENUMEROa,
 	EJOURaa,
	EMOISaa,
	EANNEaa,
	EROLEaa,
 	COLUMNSS
};
void afficherSE1(GtkWidget *liste)
{

participentSE p;


GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;
    GtkTreeIter iter;
    GtkListStore *store;

    	char CIN[30];
    	char password[30];
    	char nom[30];
   	char prenom[30];
   	char adresse[30];
 	char mail[30];
	char numero[30];
int jour;
    	int mois;
    	int anne;
   	int role;
     store=NULL;
      FILE* f;

    store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
    renderer=gtk_cell_renderer_text_new();
    column=gtk_tree_view_column_new_with_attributes(" CIN ",renderer,"text",ECINa, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

    renderer=gtk_cell_renderer_text_new();
    column=gtk_tree_view_column_new_with_attributes(" password ",renderer,"text",EPASSWORDa,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

    renderer=gtk_cell_renderer_text_new();
    column=gtk_tree_view_column_new_with_attributes(" nom ",renderer,"text",ENOMa,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
    renderer=gtk_cell_renderer_text_new();
    column=gtk_tree_view_column_new_with_attributes(" prenom ",renderer,"text",EPRENOMa,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


    renderer=gtk_cell_renderer_text_new();
    column=gtk_tree_view_column_new_with_attributes(" adresse",renderer,"text",EADRESSEa,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

    renderer=gtk_cell_renderer_text_new();
    column=gtk_tree_view_column_new_with_attributes(" mail ",renderer,"text",EMAILa,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

    renderer=gtk_cell_renderer_text_new();
    column=gtk_tree_view_column_new_with_attributes(" numero ",renderer,"text",ENUMEROa,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
    column=gtk_tree_view_column_new_with_attributes(" jour ",renderer,"text",EJOURaa, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

    renderer=gtk_cell_renderer_text_new();
    column=gtk_tree_view_column_new_with_attributes(" mois ",renderer,"text",EMOISaa,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

    renderer=gtk_cell_renderer_text_new();
    column=gtk_tree_view_column_new_with_attributes(" anne ",renderer,"text",EANNEaa,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
 
    renderer=gtk_cell_renderer_text_new();
    column=gtk_tree_view_column_new_with_attributes(" role ",renderer,"text",EROLEaa,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
  store=gtk_list_store_new(COLUMNSS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);


f = fopen("utilisateurS.txt","r");
if(f==NULL)
{
return;
}
else
{
 f=fopen("utilisateurS.txt","a+");
while (fscanf(f,"%s %s %s %s %s %s %s %d %d %d %d \n",p.CIN,p.password,p.nom,p.prenom,p.adresse,p.mail,p.numero,&p.jour,&p.mois,&p.anne,&p.role)!=EOF)
{
gtk_list_store_append (store,&iter);
gtk_list_store_set(store,&iter,ECINa,p.CIN,EPASSWORDa,p.password,ENOMa,p.nom,EPRENOMa,p.prenom,EADRESSEa,p.adresse,EMAILa,p.mail,ENUMEROa,p.numero,EJOURaa,p.jour,EMOISaa,p.mois,EANNEaa,p.anne,EROLEaa,p.role,-1);
}
fclose(f);
}
gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
g_object_unref(store);
}
}










int veriff1(char CIN[])
{
participentSE p;
int trouve=-1;
FILE *f=NULL;

char ch1[20];
f=fopen("utilisateurS.txt","r");
if (f!=NULL)
{
while(fscanf(f,"%s",ch1)!=EOF)
{
if((strcmp(ch1,CIN)==0))
trouve=1;
}
fclose(f);
}
return trouve;
}







void chercher_Ouvrier(char CIN[], int *ok)
{
participentSE p;
FILE *fp ,*fp1;
fp = fopen("utilisateurS.txt", "r+");
fp1 = fopen("uti.txt", "w+");
*ok=0;

if(fp==NULL)
{
return;
}
else
{
while(fread(&p, sizeof(p), 1, fp))
{
	if (strcmp(CIN, p.CIN)==0)
	{
		fwrite(&p, sizeof(p), 1, fp1);
		*ok=1; // ok prends la valeur 1 si cin existe *********** sinon ok = 0
	}

}
}
fclose(fp);
fclose(fp1);



}
 




void capteurdef()
{

}



	enum
{
 
 	ID1,
	ETAGE,
	VALEUR,
	DATE,
   COLUMNS12
};



/*
debit d;
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
gchar date[20], valeur[10];
FILE *f;
FILE *f1;
time_t t;
time(&t);


store=gtk_tree_view_get_model(liste);
if(store==NULL)
{
 renderer=gtk_cell_renderer_text_new();
 column=gtk_tree_view_column_new_with_attributes(" jour", renderer,"text",JOUR12, NULL);
 gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
 gtk_tree_view_column_set_expand(column,TRUE);
	
 renderer=gtk_cell_renderer_text_new();
 column=gtk_tree_view_column_new_with_attributes(" heure", renderer,"text",HEURE12, NULL);
 gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
 gtk_tree_view_column_set_expand(column,TRUE);

 renderer=gtk_cell_renderer_text_new();
 column=gtk_tree_view_column_new_with_attributes(" etage", renderer,"text",ETAGE12, NULL);
 gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
 gtk_tree_view_column_set_expand(column,TRUE);

 renderer=gtk_cell_renderer_text_new();
 column=gtk_tree_view_column_new_with_attributes(" valucap", renderer,"text",VALEUR12, NULL);
 gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
 gtk_tree_view_column_set_expand(column,TRUE);

store=gtk_list_store_new(COLUMNS12, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_FLOAT);
f=fopen("debit.txt","r");
if(f!=NULL)


  while(fscanf(f,"%d %d %d %f \n",&d.jour,&d.heure,&d.etage,&d.valucap)!=EOF)
 {
if (d.valucap<10 || d.valucap>30)
{

gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,JOUR12,d.jour,HEURE12,d.heure,ETAGE12,d.etage,VALEUR12,d.valucap,-1);
 }
}

gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
g_object_unref(store);
}
}

 fclose(f);
*/













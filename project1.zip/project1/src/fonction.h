#include <gtk/gtk.h>


typedef struct {
 char CIN[30];
 char password[30];
 char nom[30];
 char prenom[30];
 char adresse[30];
 char mail[30];
char numero[30];
 int role;
 int jour;
 int mois;
 int anne;
char num[5];

} participentSE;

void participentSE_affiche(char CIN[]);

int rechercher(char CIN[]);
int participentSE_recherche(char CIN[]);

void participentSE_modifier(char CIN[]);
void chercher_Ouvrier(char CIN[],int *ok);
void participentSE_supprimer(char CIN[]);

void participentSE_ajouter(participentSE p);
void afficherSE1(GtkWidget *liste);
void participentSE_save(participentSE p);
int remplirtab (participentSE p[],int nb);
void afficherSE(GtkWidget *liste);
void afficherSE2(GtkWidget *liste,char CIN[]);
void afficher2(GtkWidget *liste);

void vider1(GtkWidget *liste);

typedef struct {
int id;
char etage[30];
char valeur[30];
char heure[30];
}debit;
void panne(GtkWidget *liste);



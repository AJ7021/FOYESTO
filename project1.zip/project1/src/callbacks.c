#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include<string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include"fonction.h"
#include"verif.h"
#include "stok.h"
char ref[50];
int toggle;

void
on_loginSE_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *CIN, *password , *windowespaceadmine;
char CIN1[20];
char password1[20];
int trouve;
CIN = lookup_widget (button, "CINSE");
password = lookup_widget (button, "passwordSE");

strcpy(CIN1, gtk_entry_get_text(GTK_ENTRY(CIN)));
strcpy(password1, gtk_entry_get_text(GTK_ENTRY(password)));
trouve=veriff(CIN1, password1);

if (trouve==1)
{
windowespaceadmine=create_ESPACE_ADMIN  ();
 gtk_widget_show (windowespaceadmine);
GtkWidget *window6;
window6=lookup_widget(button,"smartEsprit");

gtk_widget_destroy (window6);
}

}


void
on_gestionSE_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowespaceadmin,*window6,*treeview2;
char CIN[20];
windowespaceadmin=create_GestinSE  ();
 gtk_widget_show (windowespaceadmin);

window6=lookup_widget(button,"ESPACE_ADMIN");

gtk_widget_destroy (window6);
afficherSE2(treeview2,CIN);
}


void
on_D__connexionSE_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowespaceadmin;
windowespaceadmin=create_smartEsprit  ();
 gtk_widget_show (windowespaceadmin);
GtkWidget *window6;
window6=lookup_widget(button,"ESPACE_ADMIN");

gtk_widget_destroy (window6);
}


void
on_AjouterSE_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowespaceadmin;
windowespaceadmin=create_ajouerSE  ();
 gtk_widget_show (windowespaceadmin);
GtkWidget *window6;
window6=lookup_widget(button,"GestinSE");

gtk_widget_destroy (window6);
}


void
on_ModifierSE_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowespaceadmin,*GestinSE;
windowespaceadmin=create_window7 ();
 gtk_widget_show (windowespaceadmin);
GtkWidget *window6;
window6=lookup_widget(button,"GestinSE");

gtk_widget_destroy (window6);
}


void
on_SupprimerSE_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowespaceadmin,*GestinSE;
windowespaceadmin=create_supprimerSE();
 gtk_widget_show (windowespaceadmin);
GtkWidget *window6;
window6=lookup_widget(button,"GestinSE");

gtk_widget_destroy (window6);
}


void
on_RechercheSE_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
char CIN[50];
GtkWidget *treeview,*filter;
treeview=lookup_widget(button,"treeview2");
filter=lookup_widget(button,"entry3");
strcpy(CIN,gtk_entry_get_text(GTK_ENTRY(filter)));
afficherSE2(treeview,CIN);


}


    



on_ValiderSE_clicked                   (GtkButton       *objet_graphique,
                                        gpointer         user_data)


{
int b=1;
participentSE p;
/*
FILE *f=NULL;
*/
GtkWidget *CINaa, *emailaa ,*nomaa ,*prenomaa  ,*villeaa  ,*motpasseaa,*numeroaa , *GestiInSE,*choixrole;
GtkWidget treeview1;
/*
char CINaaa[20];
char emailaaa[30];
char nomaaa[20];
char prenomaaa[20];
char motpasseaaa[20];
char villeaaa[20];
*/

FILE *f=NULL;
GtkWidget *jouraa, *moisaa ,*anneeaa , *windowespaceadmin,*combobox,*choixrolee,*window6,*labelcinse;
int trouve;
char Role[50];
char role;
GestiInSE=lookup_widget(objet_graphique,"GestinSE");

CINaa=lookup_widget(objet_graphique,"CIN");
nomaa=lookup_widget(objet_graphique,"Nom");
prenomaa=lookup_widget(objet_graphique,"Prenom");
villeaa = lookup_widget(objet_graphique,"ville");
emailaa=lookup_widget(objet_graphique,"Email");
motpasseaa=lookup_widget(objet_graphique,"Password");
numeroaa=lookup_widget(objet_graphique,"Numero");

strcpy(p.CIN,gtk_entry_get_text(GTK_ENTRY(CINaa)));
strcpy(p.mail,gtk_entry_get_text(GTK_ENTRY(emailaa)));
strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(nomaa)));
strcpy(p.prenom,gtk_entry_get_text(GTK_ENTRY(prenomaa)));
strcpy(p.adresse,gtk_entry_get_text(GTK_ENTRY(villeaa)));
strcpy(p.password,gtk_entry_get_text(GTK_ENTRY(motpasseaa)));
strcpy(p.numero,gtk_entry_get_text(GTK_ENTRY(numeroaa)));

jouraa = lookup_widget (objet_graphique, "jour");
moisaa = lookup_widget (objet_graphique, "mois");
anneeaa = lookup_widget (objet_graphique, "anne");
p.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jouraa));
p.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(moisaa));
p.anne=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(anneeaa));

choixrolee=lookup_widget(objet_graphique,"comboboxentry1");
if(strcmp("Etudiant",gtk_combo_box_get_active_text(GTK_COMBO_BOX(choixrolee)))==0)
  p.role=0;

else if(strcmp("Technicien",gtk_combo_box_get_active_text(GTK_COMBO_BOX(choixrolee)))==0)
  p.role=1;

else if(strcmp("Nutritionniste",gtk_combo_box_get_active_text(GTK_COMBO_BOX(choixrolee)))==0)
  p.role=2;

else if(strcmp("Agent de foyer",gtk_combo_box_get_active_text(GTK_COMBO_BOX(choixrolee)))==0)
  p.role=3;

else 
  p.role=4;
GtkWidget *windowespaceadmi;
participentSE_ajouter(p);

windowespaceadmin=create_GestinSE  ();

window6=lookup_widget(objet_graphique,"ajouerSE");

gtk_widget_destroy (window6);
 gtk_widget_show (windowespaceadmin);
windowespaceadmi=create_sucess ();
 gtk_widget_show (windowespaceadmi);
}
void
on_RetourSE_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *windowespaceadmin,*windowespaceadmi;
windowespaceadmin=create_GestinSE ();
 gtk_widget_show (windowespaceadmin);

GtkWidget *window6;
window6=lookup_widget(objet,"ajouerSE");

gtk_widget_destroy (window6);
}

void
on_afficher_clicked                    (GtkWidget      *objet,
                                        gpointer         user_data)
{

GtkWidget *fenetre_affiche,*w;
GtkWidget *treeview1;
GtkWidget *treeview2;
fenetre_affiche=lookup_widget(objet,"fenetre_affiche ");
fenetre_affiche= create_GestinSE();
  gtk_widget_show (fenetre_affiche);


treeview1=lookup_widget(fenetre_affiche,"treeview1");


afficherSE(treeview1);
GtkWidget *window6;
window6=lookup_widget(objet,"GestinSE");

gtk_widget_destroy (window6);

}


void
on_capteurSE_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowespaceadmin;
windowespaceadmin=create_window11 ();
 gtk_widget_show (windowespaceadmin);
GtkWidget *window6;
window6=lookup_widget(button,"ESPACE_ADMIN");

gtk_widget_destroy (window6);
}





void
on_actualiser_clicked                  (GtkWidget      *objet,
                                        gpointer         user_data)
{

GtkWidget *fenetre_affiche,*w;
GtkWidget *treeview1;
GtkWidget *treeview2;
fenetre_affiche=lookup_widget(objet,"fenetre_affiche ");
fenetre_affiche= create_GestinSE();
  gtk_widget_show (fenetre_affiche);


treeview1=lookup_widget(fenetre_affiche,"treeview1");


afficherSE(treeview1);
treeview2=lookup_widget(fenetre_affiche,"treeview2");


afficherSE(treeview2);
GtkWidget *window6;
window6=lookup_widget(objet,"GestinSE");

gtk_widget_destroy (window6);
}







void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{


GtkTreeIter iter;
gchar*      CIN        ;
gchar*      nom       ;
gchar*       prenom       ;
gchar*          adresse    ;
gchar*           mail   ;
gchar*           password   ;
gchar*          numero   ;
gint*      jour       ;
gint*      mois       ;
gint*       anne       ;
gint*       role       ;
participentSE p;
GtkTreeModel *model = gtk_tree_view_get_model(treeview);
if (gtk_tree_model_get_iter(model,&iter,path))
{

gtk_tree_model_get(GTK_LIST_STORE(model), &iter,0,&CIN,1,&password,2,&nom,3,&prenom,4,&adresse,5,&mail,6,&numero,7,&jour,8,&mois,9,&anne,10,&role,-1);

strcpy(p.CIN,CIN);
strcpy(p.password,password);
strcpy(p.nom,nom);
strcpy(p.prenom,prenom);
strcpy(p.adresse,adresse);

strcpy(p.mail ,mail );
strcpy(p.numero,numero);
participentSE_supprimer(CIN);
afficherSE(treeview);



}
}


void
on_save_clicked                        (GtkButton       *objet,
                                        gpointer         user_data)
{
participentSE p;
FILE *f=NULL;
GtkWidget *jouraa, *moisaa ,*anneeaa , *windowespaceadmin,*combobox,*choixrole;
int trouve;
char Role[50];
char role;
jouraa = lookup_widget (objet, "jour");
moisaa = lookup_widget (objet, "mois");
anneeaa = lookup_widget (objet, "anne");
p.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jouraa));
p.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(moisaa));
p.anne=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(anneeaa));

choixrole=lookup_widget(objet,"comboboxentry1");
if(strcmp("Etudiant",gtk_combo_box_get_active_text(GTK_COMBO_BOX(choixrole)))==0)
  p.role=0;

else if(strcmp("Technicien",gtk_combo_box_get_active_text(GTK_COMBO_BOX(choixrole)))==0)
  p.role=1;

else if(strcmp("Nutritionniste",gtk_combo_box_get_active_text(GTK_COMBO_BOX(choixrole)))==0)
  p.role=2;

else if(strcmp("Agent de foyer",gtk_combo_box_get_active_text(GTK_COMBO_BOX(choixrole)))==0)
  p.role=3;

else 
  p.role=4;
f=fopen("date.txt","a+");
if (f!=NULL)
{
fprintf(f,"%d %d %d %d \n",p.jour,p.mois,p.anne,p.role);
fclose(f);
}
else
printf("\n not found");
}


void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

GtkTreeIter iter;
gchar*      CIN        ;
gchar*      nom       ;
gchar*       prenom       ;
gchar*          adresse    ;
gchar*           mail   ;
gchar*           password   ;
gchar*          numero   ;
gint*      jour       ;
gint*      mois       ;
gint*       anne       ;
gint*       role       ;
participentSE p;
GtkTreeModel *model = gtk_tree_view_get_model(treeview);
if (gtk_tree_model_get_iter(model,&iter,path))
{

gtk_tree_model_get(GTK_LIST_STORE(model), &iter,0,&CIN,1,&password,2,&nom,3,&prenom,4,&adresse,5,&mail,6,&numero,7,&jour,8,&mois,9,&anne,10,&role,-1);

strcpy(p.CIN,CIN);
strcpy(p.password,password);
strcpy(p.nom,nom);
strcpy(p.prenom,prenom);
strcpy(p.adresse,adresse);

strcpy(p.mail ,mail );
strcpy(p.numero,numero);

afficherSE2(treeview,CIN);



}

}

// modifier simple mohsen //


void
on_valider1_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
participentSE p;
GtkWidget *input1;
GtkWidget *windowModification;
GtkWidget *windowModificatio;
char CIN[30];

           
GtkWidget *output1, *output2, *output3, *output4, *output5, *output6, *output7, *output8, *output9, *output10,*choixrolee1,*windowespaceadmin,*window6,*GestiInSE;
    FILE* f;
    FILE *f2;
FILE *f4;
  int jour111;
  int mois111;
  int anne111;
  int role12;
char ch1[20];
char ch2[20];
char ch3[20];
char ch4[20];
char ch5[20];
char ch6[20];
char ch7[20];
char ch8[20];
char ch9[20];


        
  
output1=lookup_widget(objet_graphique,"cin1");
output2=lookup_widget(objet_graphique,"nom1");
output3=lookup_widget(objet_graphique,"prenom1");
output4 = lookup_widget(objet_graphique,"mail");
output5=lookup_widget(objet_graphique,"password1");
output6=lookup_widget(objet_graphique,"numero1");
output7=lookup_widget(objet_graphique,"ville1");
strcpy(ch3,gtk_entry_get_text(GTK_ENTRY(output1)));
strcpy(ch4,gtk_entry_get_text(GTK_ENTRY(output4)));
strcpy(ch5,gtk_entry_get_text(GTK_ENTRY(output2)));
strcpy(ch6,gtk_entry_get_text(GTK_ENTRY(output3)));
strcpy(ch7,gtk_entry_get_text(GTK_ENTRY(output7)));
strcpy(ch8,gtk_entry_get_text(GTK_ENTRY(output5)));
strcpy(ch9,gtk_entry_get_text(GTK_ENTRY(output6)));

output8 = lookup_widget (objet_graphique, "jour1");
output9 = lookup_widget (objet_graphique, "mois1");
output10 = lookup_widget (objet_graphique, "anne1");
jour111=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(output8));
mois111=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(output9));
anne111=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(output10));
choixrolee1=lookup_widget(objet_graphique,"comboboxentry2");
if(strcmp("Etudiant",gtk_combo_box_get_active_text(GTK_COMBO_BOX(choixrolee1)))==0)
  role12=0;

else if(strcmp("Technicien",gtk_combo_box_get_active_text(GTK_COMBO_BOX(choixrolee1)))==0)
  role12=1;

else if(strcmp("Nutritionniste",gtk_combo_box_get_active_text(GTK_COMBO_BOX(choixrolee1)))==0)
  role12=2;

else if(strcmp("Agent de foyer",gtk_combo_box_get_active_text(GTK_COMBO_BOX(choixrolee1)))==0)
  role12=3;

else 
  role12=4;
 f4=fopen("uti.txt","r+");
while
(fscanf(f4," %s" ,p.CIN)!=EOF)
{ strcpy(ch1,p.CIN);}

f=fopen("utilisateurS.txt","a+");
f2=fopen("utilisateurS1.txt","a+");

if (f!=NULL)
while    (fscanf(f,"%s %s %s %s %s %s %s %d %d %d %d \n",p.CIN,p.password,p.nom,p.prenom,p.adresse,p.mail,p.numero,&p.jour,&p.mois,&p.anne,&p.role)!=EOF)
{
if
            (strcmp(ch1,p.CIN)==0)
{
fprintf(f2,"%s %s %s %s %s %s %s %d %d %d %d \n",ch3,ch8,ch5,ch6,ch7,ch4,ch9,jour111,mois111,anne111,role12);
}
else
{
fprintf(f2,"%s %s %s %s %s %s %s %d %d %d %d \n",p.CIN,p.password,p.nom,p.prenom,p.adresse,p.mail,p.numero,p.jour,p.mois,p.anne,p.role);
}
}
fclose(f4);
        fclose(f);    
        fclose(f2);
remove("utilisateurS.txt");
rename("utilisateurS1.txt","utilisateurS.txt");

windowespaceadmin=create_GestinSE  ();

window6=lookup_widget(objet_graphique,"modifierSE");

gtk_widget_destroy (window6);
 gtk_widget_show (windowespaceadmin);

}



 



void
on_save1_clicked                       (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowespaceadmin,*GestinSE;
windowespaceadmin=create_GestinSE ();
 gtk_widget_show (windowespaceadmin);
}


void
on_retour11_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowespaceadmin,*GestinSE;
windowespaceadmin=create_GestinSE ();
 gtk_widget_show (windowespaceadmin);
}


void
on_valider212_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *windowespaceadmin,*GestinSE;
windowespaceadmin=create_GestinSE ();
 gtk_widget_show (windowespaceadmin);

char CIN[20];

GtkWidget *cin;
cin=lookup_widget(button,"cin111");
strcpy(CIN,gtk_entry_get_text(GTK_ENTRY(cin)));
participentSE_supprimer(CIN);
GtkWidget *window6;
window6=lookup_widget(button,"supprimerSE");

gtk_widget_destroy (window6);

}


void
on_retour1111_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowespaceadmin,*GestinSE;
windowespaceadmin=create_GestinSE ();
 gtk_widget_show (windowespaceadmin);
}


void
on_button1Vmodifier_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{

participentSE p;
GtkWidget *CIN, *password , *windowespaceadmine;
char CIN1[20];
char password1[20];
int trouve;
CIN = lookup_widget (button, "CIN112235");
FILE* f;

strcpy(CIN1, gtk_entry_get_text(GTK_ENTRY(CIN)));
f=fopen("uti.txt","a+");

if (f!=NULL)
{
fprintf(f,"%s \n",CIN1);
}
fclose(f);

trouve=veriff1(NUM1,password12);

if (trouve==1)
{
participentSE_ajouter12345(p);
windowespaceadmine=create_modifierSE ();
 gtk_widget_show (windowespaceadmine);

GtkWidget *window6;
window6=lookup_widget(button,"window7");

gtk_widget_destroy (window6);
}

}


/*

CINaa=lookup_widget(objet_graphique,"CIN");
nomaa=lookup_widget(objet_graphique,"Nom");
prenomaa=lookup_widget(objet_graphique,"Prenom");
villeaa = lookup_widget(objet_graphique,"ville");
emailaa=lookup_widget(objet_graphique,"Email");
motpasseaa=lookup_widget(objet_graphique,"Password");
numeroaa=lookup_widget(objet_graphique,"Numero");
strcpy(p.CIN,gtk_entry_get_text(GTK_ENTRY(CINaa)));
strcpy(p.mail,gtk_entry_get_text(GTK_ENTRY(emailaa)));
strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(nomaa)));
strcpy(p.prenom,gtk_entry_get_text(GTK_ENTRY(prenomaa)));
strcpy(p.adresse,gtk_entry_get_text(GTK_ENTRY(villeaa)));
strcpy(p.password,gtk_entry_get_text(GTK_ENTRY(motpasseaa)));
strcpy(p.numero,gtk_entry_get_text(GTK_ENTRY(numeroaa)));

jouraa = lookup_widget (objet_graphique, "jour");
moisaa = lookup_widget (objet_graphique, "mois");
anneeaa = lookup_widget (objet_graphique, "anne");
p.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jouraa));
p.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(moisaa));
p.anne=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(anneeaa));


*/
	


void
on_button2R_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowespaceadmin,*GestinSE;
windowespaceadmin=create_GestinSE ();
 gtk_widget_show (windowespaceadmin);
}


void
on_treeview3_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
/*
GtkTreeIter iter;

gint*      jour       ;
gchar*      heure       ;
gchar*       etage      ;
gchar*       valucap       ;
debit d;
GtkTreeModel *model = gtk_tree_view_get_model(treeview);
if (gtk_tree_model_get_iter(model,&iter,path))
{

gtk_tree_model_get(GTK_LIST_STORE(model), &iter,0,&jour,1,&heure,2,&etage,3,&valucap,-1);


 panne(treeview);



}
*/
}


void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *p1;
GtkWidget *entry;
GtkWidget *labelNom;
GtkWidget *nbResultat;
GtkWidget *message;
char numcap[30];
char chnb[30];
int b=0,nb;
entry=lookup_widget(button,"entry4");
/*
labelNom=lookup_widget(button,"label_saisir_etage");
*/
strcpy(numcap,gtk_entry_get_text(GTK_ENTRY(entry)));
capteurdef();
strcpy(nb,gtk_entry_get_text(GTK_ENTRY(lookup_widget(button,"label_saisir_etage"))));


}


void
on_afficherBT4_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
/*
char CIN[20];
 char texte3[100]="";
GtkWidget *treeview,*filter,*fname,*output;

filter=lookup_widget(button,"afficherBT4");

FILE *f,*g;
f=fopen("debit.txt","r");
g=fopen("capteurdefectueux.txt","a+");
debit c,T[5000];
int i=0,n=0,nb=0;
if(f!=NULL)
{
while(!feof(f))
{
fscanf(f,"%d %d %d %f\n",&c.jour,&c.heure,&c.numcap,&c.valucap);
T[i].jour=c.jour;
T[i].heure=c.heure;
T[i].numcap=c.numcap;
T[i].valucap=c.valucap;
i++;
}
fclose(f);
n=i;
}
for(i=0;i<n;i++)
{
if (T[i].valucap<10 || T[i].valucap>30)
{
fprintf(g,"%d %d %d %f\n",T[i].jour,T[i].heure,T[i].numcap,T[i].valucap);
nb++;
}
}
sprintf(texte3,"le nombre des etages contient de panne est:%d/%d\n",nb,n);
output=lookup_widget(button, "label39");
gtk_label_set_text(GTK_LABEL(output),texte3);
*/
}




//modifier par treeview mohsen //
void
on_modifierpartreevi_clicked           (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *listedesetudiants;
GtkWidget *modifieretudiant;
participentSE p;
GtkWidget *treeview2;
GtkTreeSelection *selection ;
GtkTreeModel *model;
GtkTreeIter iter;
GtkToggleButton *etage11, *etage22;
GtkWidget *button;
GSList *group;

char ch1[20];
char ch2[20];
char ch3[20];
char ch4[20];
char ch5[20];
char ch6[20];
char ch7[20];
char ch8[20];
char ch9[20];

gchar*      CIN        ;
gchar*      nom       ;
gchar*       prenom       ;
gchar*          adresse    ;
gchar*           mail   ;
gchar*           password   ;
gchar*          numero   ;
gint*      jour       ;
gint*      mois       ;
gint*       anne       ;
gint*       role       ;


  int jour111;
  int mois111;
  int anne111;
  int role12;
jour111=atoi(jour);
mois111=atoi(mois);
anne111=atoi(anne);
p.jour=jour111;
p.mois=mois111;
p.anne=anne111;

GtkWidget *output1, *output2, *output3, *output4, *output5, *output6, *output7, *output8, *output9, *output10,*choixrolee1,*windowespaceadmin,*window6,*GestiInSE,*modifierSE;
GtkWidget *input7,*input8,*input1,*input4,*input5,*input6,*JOUR,*MOIS,*ANNEE;
GtkWidget *combo2;

listedesetudiants=lookup_widget(objet_graphique,"GestinSE");

    treeview2=lookup_widget(listedesetudiants,"treeview2");
    selection=gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview2));

    if(gtk_tree_selection_get_selected(selection,&model,&iter)) {

gtk_tree_model_get(GTK_LIST_STORE(model), &iter,0,&CIN,1,&nom,2,&prenom,3,&password,4,&adresse,5,&mail,6,&numero,7,&jour,8,&mois,9,&anne,10,&role,-1);

strcpy(p.CIN,CIN);
strcpy(p.nom,nom);
strcpy(p.prenom,prenom);
strcpy(p.password,password);

strcpy(p.adresse,adresse);
strcpy(p.mail ,mail );
strcpy(p.numero,numero);
}

    gtk_widget_destroy(GestiInSE);

    modifierSE=create_modifierSE();
    gtk_widget_show(modifierSE);
output1=lookup_widget(modifierSE,"cin1");
output2=lookup_widget(modifierSE,"nom1");
output3=lookup_widget(modifierSE,"prenom1");
output4=lookup_widget(modifierSE,"password1");

output5 = lookup_widget(modifierSE,"mail");

output6=lookup_widget(modifierSE,"numero1");
output7=lookup_widget(modifierSE,"ville1");

 gtk_entry_set_text(GTK_ENTRY(output1),p.CIN);
 gtk_entry_set_text(GTK_ENTRY(output2),p.nom);
 gtk_entry_set_text(GTK_ENTRY(output3),p.prenom);  
 gtk_entry_set_text(GTK_ENTRY(output4),p.password); 

 gtk_entry_set_text(GTK_ENTRY(output5),p.mail);   
 gtk_entry_set_text(GTK_ENTRY(output6),p.numero);
 gtk_entry_set_text(GTK_ENTRY(output7),p.adresse);

strcpy(ch3,gtk_entry_get_text(GTK_ENTRY(output1)));
strcpy(ch4,gtk_entry_get_text(GTK_ENTRY(output2)));
strcpy(ch5,gtk_entry_get_text(GTK_ENTRY(output3)));
strcpy(ch6,gtk_entry_get_text(GTK_ENTRY(output4)));
strcpy(ch7,gtk_entry_get_text(GTK_ENTRY(output5)));
strcpy(ch8,gtk_entry_get_text(GTK_ENTRY(output6)));
strcpy(ch9,gtk_entry_get_text(GTK_ENTRY(output7)));
output8 = lookup_widget (modifierSE, "jour1");
output9 = lookup_widget (modifierSE, "mois1");
output10 = lookup_widget (modifierSE, "anne1");

jour111=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(output8));
mois111=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(output9));
anne111=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(output10));
gtk_spin_button_set_value(output8,p.jour);
   gtk_spin_button_set_value(output9,p.mois);
   gtk_spin_button_set_value(output10,p.anne);

choixrolee1=lookup_widget(modifierSE,"comboboxentry2");
if(strcmp("Etudiant",gtk_combo_box_get_active_text(GTK_COMBO_BOX(choixrolee1)))==0)
  role12=0;

else if(strcmp("Technicien",gtk_combo_box_get_active_text(GTK_COMBO_BOX(choixrolee1)))==0)
  role12=1;

else if(strcmp("Nutritionniste",gtk_combo_box_get_active_text(GTK_COMBO_BOX(choixrolee1)))==0)
  role12=2;

else if(strcmp("Agent de foyer",gtk_combo_box_get_active_text(GTK_COMBO_BOX(choixrolee1)))==0)
  role12=3;

else 
  role12=4;
}


void
on_supprimerpartree_clicked            (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *listedesetudiants;
GtkWidget *modifieretudiant;
participentSE p;
GtkWidget *treeview2;
GtkTreeSelection *selection ;
GtkTreeModel *model;
GtkTreeIter iter;
GtkToggleButton *etage11, *etage22;
GtkWidget *button;
GSList *group;

char ch1[20];
char ch2[20];
char ch3[20];
char ch4[20];
char ch5[20];
char ch6[20];
char ch7[20];
char ch8[20];
char ch9[20];

gchar*      CIN        ;
gchar*      nom       ;
gchar*       prenom       ;
gchar*          adresse    ;
gchar*           mail   ;
gchar*           password   ;
gchar*          numero   ;
gint*      jour       ;
gint*      mois       ;
gint*       anne       ;
gint*       role       ;


  int jour111;
  int mois111;
  int anne111;
  int role12;
jour111=atoi(jour);
mois111=atoi(mois);
anne111=atoi(anne);
p.jour=jour111;
p.mois=mois111;
p.anne=anne111;

GtkWidget *output1, *output2, *output3, *output4, *output5, *output6, *output7, *output8, *output9, *output10,*choixrolee1,*windowespaceadmin,*window6,*GestiInSE,*modifierSE;
GtkWidget *input7,*input8,*input1,*input4,*input5,*input6,*JOUR,*MOIS,*ANNEE;
GtkWidget *combo2;

windowespaceadmin=lookup_widget(objet_graphique,"GestinSE");

    treeview2=lookup_widget(windowespaceadmin,"treeview2");
    selection=gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview2));

    if(gtk_tree_selection_get_selected(selection,&model,&iter)) {

gtk_tree_model_get(GTK_LIST_STORE(model), &iter,0,&CIN,1,&password,2,&nom,3,&prenom,4,&adresse,5,&mail,6,&numero,7,&jour,8,&mois,9,&anne,10,&role,-1);

strcpy(p.CIN,CIN);
strcpy(p.password,password);
strcpy(p.nom,nom);
strcpy(p.prenom,prenom);
strcpy(p.adresse,adresse);

strcpy(p.mail ,mail );
strcpy(p.numero,numero);

		windowespaceadmin= lookup_widget(objet_graphique,"GestinSE");
		gtk_widget_destroy(windowespaceadmin);
		windowespaceadmin= create_GestinSE();
		gtk_widget_show(windowespaceadmin);
		treeview2=lookup_widget(windowespaceadmin,"treeview2");
		
participentSE_supprimer(CIN);
afficherSE2(treeview2,CIN);		
}
}


void
on_button5LOGS_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowespaceadmin,*GestinSE;
windowespaceadmin=create_GESLOG ();
 gtk_widget_show (windowespaceadmin);
GtkWidget *window6;
window6=lookup_widget(button,"Welcome");

gtk_widget_destroy (window6);
}


void
on_adwelcome_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowespaceadmin,*GestinSE;
windowespaceadmin=create_smartEsprit ();
 gtk_widget_show (windowespaceadmin);
GtkWidget *window6;
window6=lookup_widget(button,"Welcome");

gtk_widget_destroy (window6);
}


void
on_LOGIN25_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *numero, *password , *windowespaceadmine;
char NUM1[20];
char password12[20];
int trouve;
numero = lookup_widget (button, "NUM_TLF");
password = lookup_widget (button, "Password25");

strcpy(NUM1, gtk_entry_get_text(GTK_ENTRY(numero)));
strcpy(password12, gtk_entry_get_text(GTK_ENTRY(password)));
trouve=veriff1(NUM1, password12);

if (trouve==1)
{
windowespaceadmine=create_SERVICE25  ();
 gtk_widget_show (windowespaceadmine);
GtkWidget *window6;
window6=lookup_widget(button,"GESLOG");

gtk_widget_destroy (window6);
}
}


void
on_BTetudiantrg_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_BTRESRTrg_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowespaceadmin;
windowespaceadmin=create_stock  ();
 gtk_widget_show (windowespaceadmin);
GtkWidget *window6;
window6=lookup_widget(button,"SERVICE25");

gtk_widget_destroy (window6);
}


void
on_BTfoyerrg_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_BTtechnrg_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_BTnutrig_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_HOMESMARTES_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowespaceadmin;
windowespaceadmin=create_Welcome ();
 gtk_widget_show (windowespaceadmin);
GtkWidget *window6;
window6=lookup_widget(button,"smartEsprit");

gtk_widget_destroy (window6);
}


void
on_HOMELOGser_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowespaceadmin;
windowespaceadmin=create_Welcome ();
 gtk_widget_show (windowespaceadmin);
GtkWidget *window6;
window6=lookup_widget(button,"GESLOG");

gtk_widget_destroy (window6);
}

int x;
int t[3]={0,0,0};
void
on_Mercredi5_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		x=6;
}

}
void
on_Vendredi5_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		x=4;
}
}

void
on_Mardi5_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		x=2;
}
}

void
on_Jeudi5_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		x=3;
}
}

void
on_Samedi5_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		x=5;
}
}

void
on_Cause2_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton)){
		t[1]=1;
	}
}


void
on_Continue12_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *output;
char texte1[100]="Mercredi";
char texte2[100]="";
char texte3[100]="";
if (x==1)
strcpy(texte1,"lundi");
else 
if
(x==2)
strcpy(texte1,"Mardi");
else
if (x==3)
strcpy(texte1,"Jeudi");
else 
if
(x==4)
strcpy(texte1,"Vendredi");
else 
if
(x==5)
strcpy(texte1,"Samdi");
else 
if
(x==6)
strcpy(texte1,"Mercredi");

if (t[0]==1)
strcat(texte2," \t Survaillence");
if (t[1]==1)
strcat(texte2," \t Panne");
if (t[2]==1)
strcat(texte2," \t Suivi");

sprintf(texte3,"l'entre dans cette service fait a %s pour %s.",texte1,texte2);
output=lookup_widget(button, "mohsentext");
gtk_label_set_text(GTK_LABEL(output),texte3);
}


void
on_Cause3_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton)){
		t[2]=1;
	}
}


void
on_Cause1_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton)){
		t[0]=1;
	}
}


void
on_Lundi5_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		x=1;
}
}

void
on_CONTINUEEEtachemohseb_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowespaceadmin;
windowespaceadmin=create_window8 ();
 gtk_widget_show (windowespaceadmin);
GtkWidget *window11;
window11=lookup_widget(button,"window11s");

gtk_widget_destroy (window11);
}





void
on_Home152_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowespaceadmin,*GestinSE;
windowespaceadmin=create_Welcome ();
 gtk_widget_show (windowespaceadmin);
GtkWidget *window6;
window6=lookup_widget(button,"GestinSE");

gtk_widget_destroy (window6);
}


void
on_ajout_clicked                       (GtkButton       *button,
                                        gpointer         user_data)
{
stock S;
GtkWidget *nom,*type,*reference,*quantite,*jour,*mois,*annee,*error;
nom=lookup_widget(button,"nom");
if (toggle==1)
{strcpy(S.type,"Biologique");}
else
strcpy(S.type,"Industriel");
reference=lookup_widget(button,"ref");
quantite=lookup_widget(button,"quant");
jour=lookup_widget(button,"Jourd");
mois=lookup_widget(button,"moisd");
annee=lookup_widget(button,"anneed");
strcpy(S.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(S.reference,gtk_entry_get_text(GTK_ENTRY(reference)));
S.quantite=atoi(gtk_entry_get_text(GTK_ENTRY(quantite)));
S.d.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
S.d.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
S.d.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
error=lookup_widget(button,"add");
ajouter(S);
gtk_label_set_text(GTK_LABEL(error),"Ajout avec succés");
}


void
on_chercher_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
char ref[50];
GtkWidget *treeview,*filter,*message;
treeview=lookup_widget(button,"treeview1b");
filter=lookup_widget(button,"refch");
strcpy(ref,gtk_entry_get_text(GTK_ENTRY(filter)));
chercher(treeview,ref);
message=lookup_widget(button,"search");
gtk_label_set_text(GTK_LABEL(message),"Voila le produit souhaitee!");
}





void
on_supprimer_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
stock x;
GtkWidget *reference,*label1;

reference=lookup_widget(button,"refch");
strcpy(x.reference,gtk_entry_get_text(GTK_ENTRY(reference)));
label1=lookup_widget(button,"delete");
supprimer(x.reference);
gtk_label_set_text(GTK_LABEL(label1),"SUPPRESSION AVEC SUCCES!");
}


void
on_modifier_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
stock x;
char ref[50];

GtkWidget *nom,*type,*reference,*quantite,*jour,*mois,*annee,*label,*filter;

nom=lookup_widget(button,"nom2");
type=lookup_widget(button,"combobox1");
reference=lookup_widget(button,"ref2");
quantite=lookup_widget(button,"quant2");
jour=lookup_widget(button,"jour2");
mois=lookup_widget(button,"mois2");
annee=lookup_widget(button,"annee2");
label=lookup_widget(button,"edit");
filter=lookup_widget(button,"refch");
strcpy(ref,gtk_entry_get_text(GTK_ENTRY(filter)));
strcpy(x.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(x.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type)));
strcpy(x.reference,gtk_entry_get_text(GTK_ENTRY(reference)));
x.quantite=atoi(gtk_entry_get_text(GTK_ENTRY(quantite)));
x.d.jour=atoi(gtk_entry_get_text(GTK_ENTRY(jour)));
x.d.mois=atoi(gtk_entry_get_text(GTK_ENTRY(mois)));
x.d.annee=atoi(gtk_entry_get_text(GTK_ENTRY(annee)));
modifier(ref,x.nom,x.type,x.reference,x.quantite,x.d.jour,x.d.mois,x.d.annee);
label=lookup_widget(button,"edit");
gtk_label_set_text(GTK_LABEL(label),"modification faite avec succés");
}




void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
	toggle=1;
}

}


void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
	toggle=2;
}
}


void
on_afficher111_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview1b;
GtkWidget *stock;
treeview1b=lookup_widget(button,"treeview1b");
afficher(treeview1b);
}


void
on_actualiser111_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview2b;
GtkWidget *stock;
treeview2b=lookup_widget(button,"treeview2b");
PERDS(treeview2b);
}





void
on_treeview1b_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_treeview2b_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


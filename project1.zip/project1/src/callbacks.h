#include <gtk/gtk.h>

void
on_ajout_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_chercher_clicked                    (GtkButton       *button,
                                        gpointer         user_data);



void
on_modifier_clicked                    (GtkButton       *button,
                                        gpointer         user_data);



void
on_supprimer_clicked                   (GtkButton       *button,
                                        gpointer         user_data);


void
on_Continue12_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_CONTINUEEEtachemohseb_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_Cause3_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Cause1_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Lundi5_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_Jeudi5_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Mercredi5_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Samedi5_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Cause2_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_Vendredi5_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Mardi5_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_BTfoyerrg_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_BTtechnrg_clicked                   (GtkButton       *button,
                                        gpointer         user_data);
void
on_BTnutrig_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_BTRESRTrg_clicked                   (GtkButton       *button,
                                        gpointer         user_data);
void
on_BTetudiantrg_clicked                (GtkButton       *button,
                                        gpointer         user_data);
void
on_Home152_clicked                     (GtkButton       *button,
                                        gpointer         user_data);
void
on_HOMELOGser_clicked                  (GtkButton       *button,
                                        gpointer         user_data);
void
on_HOMESMARTES_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5LOGS_clicked                 (GtkButton       *button,
                                        gpointer         user_data);
void
on_adwelcome_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_LOGIN25_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_loginSE_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_gestionSE_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_D__connexionSE_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_AjouterSE_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_ModifierSE_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_SupprimerSE_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_RechercheSE_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_ValiderSE_clicked                   (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_RetourSE_clicked                    (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_afficher_clicked                    (GtkWidget       *objet,
                                        gpointer        user_data);

void
on_capteurSE_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_actualiser_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_save_clicked                        (GtkButton       *objet,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_valider1_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_save1_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour11_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_valider212_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour1111_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1Vmodifier_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2R_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview3_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficherBT4_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifierpartreevi_clicked           (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_supprimerpartree_clicked            (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_afficher111_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_actualiser111_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeview4_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeview1b_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeview2b_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

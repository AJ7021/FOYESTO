#include "stok.h"
#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>
#include <stdlib.h>
enum
{
	ENOM,
	ETYPE,
	EREF,
	EQUANT,
	EJOUR,
	EMOIS,
	EANNEE,
	COLUMNS
};

void ajouter(stock S )
{
FILE *f=NULL;

f=fopen("stock.txt","a+");
if (f!=NULL)
{
	fprintf(f,"%s %s %s %d %d %d %d \n",S.nom,S.type,S.reference,S.quantite,S.d.jour,S.d.mois,S.d.annee);
	fclose(f);
	
}

}


void afficher(GtkWidget *list)
{
GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
stock S;

store=NULL;
FILE *f;
store=gtk_tree_view_get_model(list);
if (store==NULL)
	{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Nom",renderer,"text",ENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Type",renderer,"text",ETYPE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Reference",renderer,"text",EREF,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Quantite",renderer,"text",EQUANT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Jour",renderer,"text",EJOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Mois",renderer,"text",EMOIS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Annee",renderer,"text",EANNEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);
	}
store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);
f=fopen("stock.txt","r");
if (f!=NULL)
			{
	f=fopen("stock.txt","a+");
   while(fscanf(f,"%s %s %s %d %d %d %d",S.nom,S.type,S.reference,&S.quantite,&S.d.jour,&S.d.mois,&S.d.annee)!=EOF)
		{
{
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,ENOM,S.nom,ETYPE,S.type,EREF,S.reference,EQUANT,S.quantite,EJOUR,S.d.jour,EMOIS,S.d.mois,EANNEE,S.d.annee,-1);
}
		}
			}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(list),GTK_TREE_MODEL(store));
g_object_unref(store);
}	
void modifier(char ref[],char NOM[],char TYPE[],char REF[],int QUANT,int JOUR,int MOIS,int ANNEE)
{
stock S;
FILE* f;
FILE* fx;
f=fopen("stock.txt","r");
fx=fopen("st.txt","a");
if(f!=NULL&&fx!=NULL)
	{
		while(fscanf(f,"%s %s %s %d %d %d %d",S.nom,S.type,S.reference,&S.quantite,&S.d.jour,&S.d.mois,&S.d.annee)!=EOF)
			{
				if(strcmp(ref,S.reference)==0)
					{
						fprintf(fx,"%s %s %s %d %d %d %d",NOM,TYPE,REF,QUANT,JOUR,MOIS,ANNEE);
					}
				else 
				fprintf(fx,"%s %s %s %d %d %d %d",S.nom,S.type,S.reference,S.quantite,S.d.jour,S.d.mois,S.d.annee);
			}
fclose(f);
fclose(fx);
remove("stock.txt");
rename("st.txt","stock.txt");
}
}
void chercher(GtkWidget *list,char ref[])
{
GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
stock S;

store=NULL;
FILE *f;
store=gtk_tree_view_get_model(list);
if (store==NULL)
	{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Nom",renderer,"text",ENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Type",renderer,"text",ETYPE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Reference",renderer,"text",EREF,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Quantite",renderer,"text",EQUANT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Jour",renderer,"text",EJOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Mois",renderer,"text",EMOIS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Annee",renderer,"text",EANNEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);
	}
store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);
f=fopen("stock.txt","r");
if (f!=NULL)
			{
	f=fopen("stock.txt","a+");
   while(fscanf(f,"%s %s %s %d %d %d %d",S.nom,S.type,S.reference,&S.quantite,&S.d.jour,&S.d.mois,&S.d.annee)!=EOF)
		{
			if(strcmp(ref,S.reference)==0)
{
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,ENOM,S.nom,ETYPE,S.type,EREF,S.reference,EQUANT,S.quantite,EJOUR,S.d.jour,EMOIS,S.d.mois,EANNEE,S.d.annee,-1);
}
		}
			}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(list),GTK_TREE_MODEL(store));
g_object_unref(store);
}
void supprimer(char ref[])
{
stock S;
FILE *f;
FILE *fx;
f=fopen("stock.txt","r");
fx=fopen("st.txt","a");
	if(f!=NULL || fx!=NULL)
	{
		while(fscanf(f,"%s %s %s %d %d %d %d",S.nom,S.type,S.reference,&S.quantite,&S.d.jour,&S.d.mois,&S.d.annee)!=EOF)
		{
			if(strcmp(ref,S.reference)!=0)
			{
			fprintf(fx,"%s %s %s %d %d %d %d\n",S.nom,S.type,S.reference,S.quantite,S.d.jour,S.d.mois,S.d.annee);
			}
		}
		fclose(fx);
		fclose(f);
		remove("stock.txt");
		rename("st.txt","stock.txt");
	}

	
	else 
	{
	printf("\n not found");
	}
}
void PERDS(GtkWidget *list)
{
GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
stock S;

store=NULL;
FILE *f;
store=gtk_tree_view_get_model(list);
if (store==NULL)
	{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Nom",renderer,"text",ENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Type",renderer,"text",ETYPE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Reference",renderer,"text",EREF,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Quantite",renderer,"text",EQUANT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Jour",renderer,"text",EJOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Mois",renderer,"text",EMOIS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Annee",renderer,"text",EANNEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);
	}
store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);
f=fopen("stock.txt","r");
if (f!=NULL)
			{
	f=fopen("stock.txt","a+");
   while(fscanf(f,"%s %s %s %d %d %d %d",S.nom,S.type,S.reference,&S.quantite,&S.d.jour,&S.d.mois,&S.d.annee)!=EOF)
		{
			if(S.quantite==0)
{
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,ENOM,S.nom,ETYPE,S.type,EREF,S.reference,EQUANT,S.quantite,EJOUR,S.d.jour,EMOIS,S.d.mois,EANNEE,S.d.annee,-1);
}
		}
			}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(list),GTK_TREE_MODEL(store));
g_object_unref(store);
}
	


#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include<string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include"fonction.h"
#include"verif.h"
#include "stok.h"
#include"CRUD.h"
#include"tree.h"
#include"treeview.h"
#include"function.h"
#include "treee.h"
#include "capteurs.h"
char ref[50];
int toggle;

void
on_loginSE_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *CIN, *password , *windowespaceadmine;
char CIN1[20];
char password1[20];
int trouve;
CIN = lookup_widget (button, "CINSE");
password = lookup_widget (button, "passwordSE");

strcpy(CIN1, gtk_entry_get_text(GTK_ENTRY(CIN)));
strcpy(password1, gtk_entry_get_text(GTK_ENTRY(password)));
trouve=veriff(CIN1, password1);

if (trouve==1)
{
windowespaceadmine=create_ESPACE_ADMIN  ();
 gtk_widget_show (windowespaceadmine);
GtkWidget *window6;
window6=lookup_widget(button,"smartEsprit");

gtk_widget_destroy (window6);
}

}


void
on_gestionSE_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowespaceadmin,*window6,*treeview2;
char CIN[20];
windowespaceadmin=create_GestinSE  ();
 gtk_widget_show (windowespaceadmin);

window6=lookup_widget(button,"ESPACE_ADMIN");

gtk_widget_destroy (window6);
afficherSE2(treeview2,CIN);
}


void
on_D__connexionSE_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowespaceadmin;
windowespaceadmin=create_smartEsprit  ();
 gtk_widget_show (windowespaceadmin);
GtkWidget *window6;
window6=lookup_widget(button,"ESPACE_ADMIN");

gtk_widget_destroy (window6);
}


void
on_AjouterSE_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowespaceadmin;
windowespaceadmin=create_ajouerSE  ();
 gtk_widget_show (windowespaceadmin);
GtkWidget *window6;
window6=lookup_widget(button,"GestinSE");

gtk_widget_destroy (window6);
}


void
on_ModifierSE_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowespaceadmin,*GestinSE;
windowespaceadmin=create_window7 ();
 gtk_widget_show (windowespaceadmin);
GtkWidget *window6;
window6=lookup_widget(button,"GestinSE");

gtk_widget_destroy (window6);
}


void
on_SupprimerSE_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowespaceadmin,*GestinSE;
windowespaceadmin=create_supprimerSE();
 gtk_widget_show (windowespaceadmin);
GtkWidget *window6;
window6=lookup_widget(button,"GestinSE");

gtk_widget_destroy (window6);
}


void
on_RechercheSE_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
char CIN[50];
GtkWidget *treeview,*filter;
treeview=lookup_widget(button,"treeview2");
filter=lookup_widget(button,"entry3");
strcpy(CIN,gtk_entry_get_text(GTK_ENTRY(filter)));
afficherSE2(treeview,CIN);


}


    



on_ValiderSE_clicked                   (GtkButton       *objet_graphique,
                                        gpointer         user_data)


{
int b=1;
participentSE p;
/*
FILE *f=NULL;
*/
GtkWidget *CINaa, *emailaa ,*nomaa ,*prenomaa  ,*villeaa  ,*motpasseaa,*numeroaa , *GestiInSE,*choixrole;
GtkWidget treeview1;
/*
char CINaaa[20];
char emailaaa[30];
char nomaaa[20];
char prenomaaa[20];
char motpasseaaa[20];
char villeaaa[20];
*/

FILE *f=NULL;
GtkWidget *jouraa, *moisaa ,*anneeaa , *windowespaceadmin,*combobox,*choixrolee,*window6,*labelcinse;
int trouve;
char Role[50];
char role;
GestiInSE=lookup_widget(objet_graphique,"GestinSE");

CINaa=lookup_widget(objet_graphique,"CIN");
nomaa=lookup_widget(objet_graphique,"Nom");
prenomaa=lookup_widget(objet_graphique,"Prenom");
villeaa = lookup_widget(objet_graphique,"ville");
emailaa=lookup_widget(objet_graphique,"Email");
motpasseaa=lookup_widget(objet_graphique,"Password");
numeroaa=lookup_widget(objet_graphique,"Numero");

strcpy(p.CIN,gtk_entry_get_text(GTK_ENTRY(CINaa)));
strcpy(p.mail,gtk_entry_get_text(GTK_ENTRY(emailaa)));
strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(nomaa)));
strcpy(p.prenom,gtk_entry_get_text(GTK_ENTRY(prenomaa)));
strcpy(p.adresse,gtk_entry_get_text(GTK_ENTRY(villeaa)));
strcpy(p.password,gtk_entry_get_text(GTK_ENTRY(motpasseaa)));
strcpy(p.numero,gtk_entry_get_text(GTK_ENTRY(numeroaa)));

jouraa = lookup_widget (objet_graphique, "jour");
moisaa = lookup_widget (objet_graphique, "mois");
anneeaa = lookup_widget (objet_graphique, "anne");
p.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jouraa));
p.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(moisaa));
p.anne=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(anneeaa));

choixrolee=lookup_widget(objet_graphique,"comboboxentry1");
if(strcmp("Etudiant",gtk_combo_box_get_active_text(GTK_COMBO_BOX(choixrolee)))==0)
  p.role=0;

else if(strcmp("Technicien",gtk_combo_box_get_active_text(GTK_COMBO_BOX(choixrolee)))==0)
  p.role=1;

else if(strcmp("Nutritionniste",gtk_combo_box_get_active_text(GTK_COMBO_BOX(choixrolee)))==0)
  p.role=2;

else if(strcmp("Agent de foyer",gtk_combo_box_get_active_text(GTK_COMBO_BOX(choixrolee)))==0)
  p.role=3;

else 
  p.role=4;
GtkWidget *windowespaceadmi;
participentSE_ajouter(p);

windowespaceadmin=create_GestinSE  ();

window6=lookup_widget(objet_graphique,"ajouerSE");

gtk_widget_destroy (window6);
 gtk_widget_show (windowespaceadmin);
GtkWidget *id,*warn;
warn=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"ajouté avec succeès");
	switch(gtk_dialog_run(GTK_DIALOG(warn)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(warn);
	break;
	}
}
void
on_RetourSE_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *windowespaceadmin,*windowespaceadmi;
windowespaceadmin=create_GestinSE ();
 gtk_widget_show (windowespaceadmin);

GtkWidget *window6;
window6=lookup_widget(objet,"ajouerSE");

gtk_widget_destroy (window6);
}

void
on_afficher_clicked                    (GtkWidget      *objet,
                                        gpointer         user_data)
{

GtkWidget *fenetre_affiche,*w;
GtkWidget *treeview1;
GtkWidget *treeview2;
fenetre_affiche=lookup_widget(objet,"fenetre_affiche ");
fenetre_affiche= create_GestinSE();
  gtk_widget_show (fenetre_affiche);


treeview1=lookup_widget(fenetre_affiche,"treeview1");


afficherSE(treeview1);
GtkWidget *window6;
window6=lookup_widget(objet,"GestinSE");

gtk_widget_destroy (window6);

}


void
on_capteurSE_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowespaceadmin;
windowespaceadmin=create_window11 ();
 gtk_widget_show (windowespaceadmin);
GtkWidget *window6;
window6=lookup_widget(button,"ESPACE_ADMIN");

gtk_widget_destroy (window6);
}





void
on_actualiser_clicked                  (GtkWidget      *objet,
                                        gpointer         user_data)
{

GtkWidget *fenetre_affiche,*w;
GtkWidget *treeview1;
GtkWidget *treeview2;
fenetre_affiche=lookup_widget(objet,"fenetre_affiche ");
fenetre_affiche= create_GestinSE();
  gtk_widget_show (fenetre_affiche);


treeview1=lookup_widget(fenetre_affiche,"treeview1");


afficherSE(treeview1);
treeview2=lookup_widget(fenetre_affiche,"treeview2");


afficherSE(treeview2);
GtkWidget *window6;
window6=lookup_widget(objet,"GestinSE");

gtk_widget_destroy (window6);
}







void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{


GtkTreeIter iter;
gchar*      CIN        ;
gchar*      nom       ;
gchar*       prenom       ;
gchar*          adresse    ;
gchar*           mail   ;
gchar*           password   ;
gchar*          numero   ;
gint*      jour       ;
gint*      mois       ;
gint*       anne       ;
gint*       role       ;
participentSE p;
GtkTreeModel *model = gtk_tree_view_get_model(treeview);
if (gtk_tree_model_get_iter(model,&iter,path))
{

gtk_tree_model_get(GTK_LIST_STORE(model), &iter,0,&CIN,1,&password,2,&nom,3,&prenom,4,&adresse,5,&mail,6,&numero,7,&jour,8,&mois,9,&anne,10,&role,-1);

strcpy(p.CIN,CIN);
strcpy(p.password,password);
strcpy(p.nom,nom);
strcpy(p.prenom,prenom);
strcpy(p.adresse,adresse);

strcpy(p.mail ,mail );
strcpy(p.numero,numero);
participentSE_supprimer(CIN);
afficherSE(treeview);



}
}


void
on_save_clicked                        (GtkButton       *objet,
                                        gpointer         user_data)
{
participentSE p;
FILE *f=NULL;
GtkWidget *jouraa, *moisaa ,*anneeaa , *windowespaceadmin,*combobox,*choixrole;
int trouve;
char Role[50];
char role;
jouraa = lookup_widget (objet, "jour");
moisaa = lookup_widget (objet, "mois");
anneeaa = lookup_widget (objet, "anne");
p.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jouraa));
p.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(moisaa));
p.anne=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(anneeaa));

choixrole=lookup_widget(objet,"comboboxentry1");
if(strcmp("Etudiant",gtk_combo_box_get_active_text(GTK_COMBO_BOX(choixrole)))==0)
  p.role=0;

else if(strcmp("Technicien",gtk_combo_box_get_active_text(GTK_COMBO_BOX(choixrole)))==0)
  p.role=1;

else if(strcmp("Nutritionniste",gtk_combo_box_get_active_text(GTK_COMBO_BOX(choixrole)))==0)
  p.role=2;

else if(strcmp("Agent de foyer",gtk_combo_box_get_active_text(GTK_COMBO_BOX(choixrole)))==0)
  p.role=3;

else 
  p.role=4;
f=fopen("date.txt","a+");
if (f!=NULL)
{
fprintf(f,"%d %d %d %d \n",p.jour,p.mois,p.anne,p.role);
fclose(f);
}
else
printf("\n not found");
}


void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

GtkTreeIter iter;
gchar*      CIN        ;
gchar*      nom       ;
gchar*       prenom       ;
gchar*          adresse    ;
gchar*           mail   ;
gchar*           password   ;
gchar*          numero   ;
gint*      jour       ;
gint*      mois       ;
gint*       anne       ;
gint*       role       ;
participentSE p;
GtkTreeModel *model = gtk_tree_view_get_model(treeview);
if (gtk_tree_model_get_iter(model,&iter,path))
{

gtk_tree_model_get(GTK_LIST_STORE(model), &iter,0,&CIN,1,&password,2,&nom,3,&prenom,4,&adresse,5,&mail,6,&numero,7,&jour,8,&mois,9,&anne,10,&role,-1);

strcpy(p.CIN,CIN);
strcpy(p.password,password);
strcpy(p.nom,nom);
strcpy(p.prenom,prenom);
strcpy(p.adresse,adresse);

strcpy(p.mail ,mail );
strcpy(p.numero,numero);

afficherSE2(treeview,CIN);



}

}

// modifier simple mohsen //


void
on_valider1_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
participentSE p;
GtkWidget *input1;
GtkWidget *windowModification;
GtkWidget *windowModificatio;
char CIN[30];

           
GtkWidget *output1, *output2, *output3, *output4, *output5, *output6, *output7, *output8, *output9, *output10,*choixrolee1,*windowespaceadmin,*window6,*GestiInSE;
    FILE* f;
    FILE *f2;
FILE *f4;
  int jour111;
  int mois111;
  int anne111;
  int role12;
char ch1[20];
char ch2[20];
char ch3[20];
char ch4[20];
char ch5[20];
char ch6[20];
char ch7[20];
char ch8[20];
char ch9[20];


        
  
output1=lookup_widget(objet_graphique,"cin1");
output2=lookup_widget(objet_graphique,"nom1");
output3=lookup_widget(objet_graphique,"prenom1");
output4 = lookup_widget(objet_graphique,"mail");
output5=lookup_widget(objet_graphique,"password1");
output6=lookup_widget(objet_graphique,"numero1");
output7=lookup_widget(objet_graphique,"ville1");
strcpy(ch3,gtk_entry_get_text(GTK_ENTRY(output1)));
strcpy(ch4,gtk_entry_get_text(GTK_ENTRY(output4)));
strcpy(ch5,gtk_entry_get_text(GTK_ENTRY(output2)));
strcpy(ch6,gtk_entry_get_text(GTK_ENTRY(output3)));
strcpy(ch7,gtk_entry_get_text(GTK_ENTRY(output7)));
strcpy(ch8,gtk_entry_get_text(GTK_ENTRY(output5)));
strcpy(ch9,gtk_entry_get_text(GTK_ENTRY(output6)));

output8 = lookup_widget (objet_graphique, "jour1");
output9 = lookup_widget (objet_graphique, "mois1");
output10 = lookup_widget (objet_graphique, "anne1");
jour111=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(output8));
mois111=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(output9));
anne111=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(output10));
choixrolee1=lookup_widget(objet_graphique,"comboboxentry2");
if(strcmp("Etudiant",gtk_combo_box_get_active_text(GTK_COMBO_BOX(choixrolee1)))==0)
  role12=0;

else if(strcmp("Technicien",gtk_combo_box_get_active_text(GTK_COMBO_BOX(choixrolee1)))==0)
  role12=1;

else if(strcmp("Nutritionniste",gtk_combo_box_get_active_text(GTK_COMBO_BOX(choixrolee1)))==0)
  role12=2;

else if(strcmp("Agent de foyer",gtk_combo_box_get_active_text(GTK_COMBO_BOX(choixrolee1)))==0)
  role12=3;

else 
  role12=4;
 f4=fopen("uti.txt","r+");
while
(fscanf(f4," %s" ,p.CIN)!=EOF)
{ strcpy(ch1,p.CIN);}

f=fopen("utilisateurS.txt","a+");
f2=fopen("utilisateurS1.txt","a+");

if (f!=NULL)
while    (fscanf(f,"%s %s %s %s %s %s %s %d %d %d %d \n",p.CIN,p.password,p.nom,p.prenom,p.adresse,p.mail,p.numero,&p.jour,&p.mois,&p.anne,&p.role)!=EOF)
{
if
            (strcmp(ch1,p.CIN)==0)
{
fprintf(f2,"%s %s %s %s %s %s %s %d %d %d %d \n",ch3,ch8,ch5,ch6,ch7,ch4,ch9,jour111,mois111,anne111,role12);
}
else
{
fprintf(f2,"%s %s %s %s %s %s %s %d %d %d %d \n",p.CIN,p.password,p.nom,p.prenom,p.adresse,p.mail,p.numero,p.jour,p.mois,p.anne,p.role);
}
}
fclose(f4);
        fclose(f);    
        fclose(f2);
remove("utilisateurS.txt");
rename("utilisateurS1.txt","utilisateurS.txt");

windowespaceadmin=create_GestinSE  ();

window6=lookup_widget(objet_graphique,"modifierSE");


gtk_widget_destroy (window6);
 gtk_widget_show (windowespaceadmin);
GtkWidget *id,*warn;
warn=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"modifié avec succeès");
	switch(gtk_dialog_run(GTK_DIALOG(warn)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(warn);
	break;
	}

}



 



void
on_save1_clicked                       (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowespaceadmin,*GestinSE;
windowespaceadmin=create_GestinSE ();
 gtk_widget_show (windowespaceadmin);
}


void
on_retour11_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowespaceadmin,*GestinSE,*window6;
windowespaceadmin=create_GestinSE ();
 gtk_widget_show (windowespaceadmin);
window6=lookup_widget(button,"modifierSE");

gtk_widget_destroy (window6);
}


void
on_valider212_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *windowespaceadmin,*GestinSE;
windowespaceadmin=create_GestinSE ();
 gtk_widget_show (windowespaceadmin);

char CIN[20];

GtkWidget *cin;
cin=lookup_widget(button,"cin111");
strcpy(CIN,gtk_entry_get_text(GTK_ENTRY(cin)));
participentSE_supprimer(CIN);
GtkWidget *window6;
window6=lookup_widget(button,"supprimerSE");

gtk_widget_destroy (window6);

}


void
on_retour1111_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowespaceadmin,*GestinSE;
windowespaceadmin=create_GestinSE ();
 gtk_widget_show (windowespaceadmin);
}


void
on_button1Vmodifier_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
participentSE p;
GtkWidget *input1;
GtkWidget *windowModification;
GtkWidget *windowModificatio;
char CIN[30];
FILE *f;
f = fopen("utilisateurS", "r");
input1 = lookup_widget(button, "CINmodif1");
windowModification = create_modifierSE();
gtk_widget_show(windowModification);

}


/*

CINaa=lookup_widget(objet_graphique,"CIN");
nomaa=lookup_widget(objet_graphique,"Nom");
prenomaa=lookup_widget(objet_graphique,"Prenom");
villeaa = lookup_widget(objet_graphique,"ville");
emailaa=lookup_widget(objet_graphique,"Email");
motpasseaa=lookup_widget(objet_graphique,"Password");
numeroaa=lookup_widget(objet_graphique,"Numero");
strcpy(p.CIN,gtk_entry_get_text(GTK_ENTRY(CINaa)));
strcpy(p.mail,gtk_entry_get_text(GTK_ENTRY(emailaa)));
strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(nomaa)));
strcpy(p.prenom,gtk_entry_get_text(GTK_ENTRY(prenomaa)));
strcpy(p.adresse,gtk_entry_get_text(GTK_ENTRY(villeaa)));
strcpy(p.password,gtk_entry_get_text(GTK_ENTRY(motpasseaa)));
strcpy(p.numero,gtk_entry_get_text(GTK_ENTRY(numeroaa)));

jouraa = lookup_widget (objet_graphique, "jour");
moisaa = lookup_widget (objet_graphique, "mois");
anneeaa = lookup_widget (objet_graphique, "anne");
p.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jouraa));
p.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(moisaa));
p.anne=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(anneeaa));


*/
	


void
on_button2R_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowespaceadmin,*GestinSE;
windowespaceadmin=create_GestinSE ();
 gtk_widget_show (windowespaceadmin);
}


void
on_treeview3_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
/*
GtkTreeIter iter;

gint*      jour       ;
gchar*      heure       ;
gchar*       etage      ;
gchar*       valucap       ;
debit d;
GtkTreeModel *model = gtk_tree_view_get_model(treeview);
if (gtk_tree_model_get_iter(model,&iter,path))
{

gtk_tree_model_get(GTK_LIST_STORE(model), &iter,0,&jour,1,&heure,2,&etage,3,&valucap,-1);


 panne(treeview);



}
*/
}


void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *p1;
GtkWidget *entry;
GtkWidget *labelNom;
GtkWidget *nbResultat;
GtkWidget *message;
char numcap[30];
char chnb[30];
int b=0,nb;
entry=lookup_widget(button,"entry4");
/*
labelNom=lookup_widget(button,"label_saisir_etage");
*/
strcpy(numcap,gtk_entry_get_text(GTK_ENTRY(entry)));
capteurdef();
strcpy(nb,gtk_entry_get_text(GTK_ENTRY(lookup_widget(button,"label_saisir_etage"))));


}


void
on_afficherBT4_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

char CIN[20];
 char texte3[100]="";
GtkWidget *treeview,*filter,*fname,*output;

filter=lookup_widget(button,"afficherBT4");

FILE *f,*g;
f=fopen("debit.txt","r");
g=fopen("capteurdefectueux.txt","a+");
debit c,T[5000];
int i=0,n=0,nb=0;
if(f!=NULL)
{
while(!feof(f))
{
fscanf(f,"%d %d %d %f\n",&c.jour,&c.heure,&c.numcap,&c.valucap);
T[i].jour=c.jour;
T[i].heure=c.heure;
T[i].numcap=c.numcap;
T[i].valucap=c.valucap;
i++;
}
fclose(f);
n=i;
}
for(i=0;i<n;i++)
{
if (T[i].valucap<10 || T[i].valucap>30)
{
fprintf(g,"%d %d %d %f\n",T[i].jour,T[i].heure,T[i].numcap,T[i].valucap);
nb++;
}
}
sprintf(texte3,"le nombre des etages contient de panne est:%d/%d\n",nb,n);
output=lookup_widget(button, "label39");
gtk_label_set_text(GTK_LABEL(output),texte3);

}




//modifier par treeview mohsen //
void
on_modifierpartreevi_clicked           (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *listedesetudiants;
GtkWidget *modifieretudiant;
participentSE p;
GtkWidget *treeview2;
GtkTreeSelection *selection ;
GtkTreeModel *model;
GtkTreeIter iter;
GtkToggleButton *etage11, *etage22;
GtkWidget *button;
GSList *group;

char ch1[20];
char ch2[20];
char ch3[20];
char ch4[20];
char ch5[20];
char ch6[20];
char ch7[20];
char ch8[20];
char ch9[20];

gchar*      CIN        ;
gchar*      nom       ;
gchar*       prenom       ;
gchar*          adresse    ;
gchar*           mail   ;
gchar*           password   ;
gchar*          numero   ;
gint*      jour       ;
gint*      mois       ;
gint*       anne       ;
gint*       role       ;


  int jour111;
  int mois111;
  int anne111;
  int role12;
jour111=atoi(jour);
mois111=atoi(mois);
anne111=atoi(anne);
p.jour=jour111;
p.mois=mois111;
p.anne=anne111;

GtkWidget *output1, *output2, *output3, *output4, *output5, *output6, *output7, *output8, *output9, *output10,*choixrolee1,*windowespaceadmin,*window6,*GestiInSE,*modifierSE;
GtkWidget *input7,*input8,*input1,*input4,*input5,*input6,*JOUR,*MOIS,*ANNEE;
GtkWidget *combo2;

listedesetudiants=lookup_widget(objet_graphique,"GestinSE");

    treeview2=lookup_widget(listedesetudiants,"treeview2");
    selection=gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview2));

    if(gtk_tree_selection_get_selected(selection,&model,&iter)) {

gtk_tree_model_get(GTK_LIST_STORE(model), &iter,0,&CIN,1,&nom,2,&prenom,3,&password,4,&adresse,5,&mail,6,&numero,7,&jour,8,&mois,9,&anne,10,&role,-1);

strcpy(p.CIN,CIN);
strcpy(p.nom,nom);
strcpy(p.prenom,prenom);
strcpy(p.password,password);

strcpy(p.adresse,adresse);
strcpy(p.mail ,mail );
strcpy(p.numero,numero);
}

    gtk_widget_destroy(GestiInSE);

    modifierSE=create_modifierSE();
    gtk_widget_show(modifierSE);
output1=lookup_widget(modifierSE,"cin1");
output2=lookup_widget(modifierSE,"nom1");
output3=lookup_widget(modifierSE,"prenom1");
output4=lookup_widget(modifierSE,"password1");

output5 = lookup_widget(modifierSE,"mail");

output6=lookup_widget(modifierSE,"numero1");
output7=lookup_widget(modifierSE,"ville1");

 gtk_entry_set_text(GTK_ENTRY(output1),p.CIN);
 gtk_entry_set_text(GTK_ENTRY(output2),p.nom);
 gtk_entry_set_text(GTK_ENTRY(output3),p.prenom);  
 gtk_entry_set_text(GTK_ENTRY(output4),p.password); 

 gtk_entry_set_text(GTK_ENTRY(output5),p.mail);   
 gtk_entry_set_text(GTK_ENTRY(output6),p.numero);
 gtk_entry_set_text(GTK_ENTRY(output7),p.adresse);

strcpy(ch3,gtk_entry_get_text(GTK_ENTRY(output1)));
strcpy(ch4,gtk_entry_get_text(GTK_ENTRY(output2)));
strcpy(ch5,gtk_entry_get_text(GTK_ENTRY(output3)));
strcpy(ch6,gtk_entry_get_text(GTK_ENTRY(output4)));
strcpy(ch7,gtk_entry_get_text(GTK_ENTRY(output5)));
strcpy(ch8,gtk_entry_get_text(GTK_ENTRY(output6)));
strcpy(ch9,gtk_entry_get_text(GTK_ENTRY(output7)));
output8 = lookup_widget (modifierSE, "jour1");
output9 = lookup_widget (modifierSE, "mois1");
output10 = lookup_widget (modifierSE, "anne1");

jour111=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(output8));
mois111=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(output9));
anne111=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(output10));
gtk_spin_button_set_value(output8,p.jour);
   gtk_spin_button_set_value(output9,p.mois);
   gtk_spin_button_set_value(output10,p.anne);

choixrolee1=lookup_widget(modifierSE,"comboboxentry2");
if(strcmp("Etudiant",gtk_combo_box_get_active_text(GTK_COMBO_BOX(choixrolee1)))==0)
  role12=0;

else if(strcmp("Technicien",gtk_combo_box_get_active_text(GTK_COMBO_BOX(choixrolee1)))==0)
  role12=1;

else if(strcmp("Nutritionniste",gtk_combo_box_get_active_text(GTK_COMBO_BOX(choixrolee1)))==0)
  role12=2;

else if(strcmp("Agent de foyer",gtk_combo_box_get_active_text(GTK_COMBO_BOX(choixrolee1)))==0)
  role12=3;

else 
  role12=4;
}


void
on_supprimerpartree_clicked            (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *listedesetudiants;
GtkWidget *modifieretudiant;
participentSE p;
GtkWidget *treeview2;
GtkTreeSelection *selection ;
GtkTreeModel *model;
GtkTreeIter iter;
GtkToggleButton *etage11, *etage22;
GtkWidget *button;
GSList *group;

char ch1[20];
char ch2[20];
char ch3[20];
char ch4[20];
char ch5[20];
char ch6[20];
char ch7[20];
char ch8[20];
char ch9[20];

gchar*      CIN        ;
gchar*      nom       ;
gchar*       prenom       ;
gchar*          adresse    ;
gchar*           mail   ;
gchar*           password   ;
gchar*          numero   ;
gint*      jour       ;
gint*      mois       ;
gint*       anne       ;
gint*       role       ;


  int jour111;
  int mois111;
  int anne111;
  int role12;
jour111=atoi(jour);
mois111=atoi(mois);
anne111=atoi(anne);
p.jour=jour111;
p.mois=mois111;
p.anne=anne111;

GtkWidget *output1, *output2, *output3, *output4, *output5, *output6, *output7, *output8, *output9, *output10,*choixrolee1,*windowespaceadmin,*window6,*GestiInSE,*modifierSE;
GtkWidget *input7,*input8,*input1,*input4,*input5,*input6,*JOUR,*MOIS,*ANNEE;
GtkWidget *combo2;

windowespaceadmin=lookup_widget(objet_graphique,"GestinSE");

    treeview2=lookup_widget(windowespaceadmin,"treeview2");
    selection=gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview2));

    if(gtk_tree_selection_get_selected(selection,&model,&iter)) {

gtk_tree_model_get(GTK_LIST_STORE(model), &iter,0,&CIN,1,&password,2,&nom,3,&prenom,4,&adresse,5,&mail,6,&numero,7,&jour,8,&mois,9,&anne,10,&role,-1);

strcpy(p.CIN,CIN);
strcpy(p.password,password);
strcpy(p.nom,nom);
strcpy(p.prenom,prenom);
strcpy(p.adresse,adresse);

strcpy(p.mail ,mail );
strcpy(p.numero,numero);

		windowespaceadmin= lookup_widget(objet_graphique,"GestinSE");
		gtk_widget_destroy(windowespaceadmin);
		windowespaceadmin= create_GestinSE();
		gtk_widget_show(windowespaceadmin);
		treeview2=lookup_widget(windowespaceadmin,"treeview2");
		
participentSE_supprimer(CIN);
afficherSE2(treeview2,CIN);		
}
}


void
on_button5LOGS_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowespaceadmin,*GestinSE;
windowespaceadmin=create_GESLOG ();
 gtk_widget_show (windowespaceadmin);
GtkWidget *window6;
window6=lookup_widget(button,"Welcome");

gtk_widget_destroy (window6);
}


void
on_adwelcome_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowespaceadmin,*GestinSE;
windowespaceadmin=create_smartEsprit ();
 gtk_widget_show (windowespaceadmin);
GtkWidget *window6;
window6=lookup_widget(button,"Welcome");

gtk_widget_destroy (window6);
}


void
on_LOGIN25_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *numero, *password , *windowespaceadmine;
char NUM1[20];
char password12[20];
int trouve;
numero = lookup_widget (button, "NUM_TLF");
password = lookup_widget (button, "Password25");

strcpy(NUM1, gtk_entry_get_text(GTK_ENTRY(numero)));
strcpy(password12, gtk_entry_get_text(GTK_ENTRY(password)));
trouve=veriff1(NUM1, password12);

if (trouve==1)
{
windowespaceadmine=create_SERVICE25  ();
 gtk_widget_show (windowespaceadmine);
GtkWidget *window6;
window6=lookup_widget(button,"GESLOG");

gtk_widget_destroy (window6);
}
}


void
on_BTetudiantrg_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_BTRESRTrg_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowespaceadmin;
windowespaceadmin=create_stock  ();
 gtk_widget_show (windowespaceadmin);
GtkWidget *window6;
window6=lookup_widget(button,"SERVICE25");

gtk_widget_destroy (window6);
}




void
on_BTtechnrg_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *p, *p1, *p2, *p3;
GtkWidget *windowdash, *windowcapteur;

windowcapteur= create_WindowGestiondescapteurs();


p=lookup_widget(windowcapteur,"treeview1n");
p1=lookup_widget(windowcapteur,"TreeViewAffichageAlarmante");
p2=lookup_widget(windowcapteur,"treeview2n");
p3=lookup_widget(windowcapteur,"treeview3n");

Capteurtree(p,"capteurs.txt");
Alarmantetree(p1,"alarmantes.txt");
ChercherCapteur(p2,"capteurs.txt");
Defectueuxtree(p3,"defectueux.txt");


windowdash=lookup_widget(windowcapteur,"SERVICE25");

gtk_widget_destroy(windowdash);
gtk_widget_show(windowcapteur);
}



void
on_HOMESMARTES_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowespaceadmin;
windowespaceadmin=create_Welcome ();
 gtk_widget_show (windowespaceadmin);
GtkWidget *window6;
window6=lookup_widget(button,"smartEsprit");

gtk_widget_destroy (window6);
}


void
on_HOMELOGser_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowespaceadmin;
windowespaceadmin=create_Welcome ();
 gtk_widget_show (windowespaceadmin);
GtkWidget *window6;
window6=lookup_widget(button,"GESLOG");

gtk_widget_destroy (window6);
}

int x;
int t[3]={0,0,0};
void
on_Mercredi5_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		x=6;
}

}
void
on_Vendredi5_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		x=4;
}
}

void
on_Mardi5_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		x=2;
}
}

void
on_Jeudi5_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		x=3;
}
}

void
on_Samedi5_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		x=5;
}
}

void
on_Cause2_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton)){
		t[1]=1;
	}
}


void
on_Continue12_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *output;
char texte1[100]="Mercredi";
char texte2[100]="";
char texte3[100]="";
if (x==1)
strcpy(texte1,"lundi");
else 
if
(x==2)
strcpy(texte1,"Mardi");
else
if (x==3)
strcpy(texte1,"Jeudi");
else 
if
(x==4)
strcpy(texte1,"Vendredi");
else 
if
(x==5)
strcpy(texte1,"Samdi");
else 
if
(x==6)
strcpy(texte1,"Mercredi");

if (t[0]==1)
strcat(texte2," \t Survaillence");
if (t[1]==1)
strcat(texte2," \t Panne");
if (t[2]==1)
strcat(texte2," \t Suivi");

sprintf(texte3,"l'entre dans cette service fait a %s pour %s.",texte1,texte2);
output=lookup_widget(button, "mohsentext");
gtk_label_set_text(GTK_LABEL(output),texte3);
}


void
on_Cause3_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton)){
		t[2]=1;
	}
}


void
on_Cause1_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton)){
		t[0]=1;
	}
}


void
on_Lundi5_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		x=1;
}
}

void
on_CONTINUEEEtachemohseb_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowespaceadmin;
windowespaceadmin=create_window8 ();
 gtk_widget_show (windowespaceadmin);
GtkWidget *window11;
window11=lookup_widget(button,"window11s");

gtk_widget_destroy (window11);
}





void
on_Home152_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowespaceadmin,*GestinSE;
windowespaceadmin=create_Welcome ();
 gtk_widget_show (windowespaceadmin);
GtkWidget *window6;
window6=lookup_widget(button,"GestinSE");

gtk_widget_destroy (window6);
}


void
on_ajout_clicked                       (GtkButton       *button,
                                        gpointer         user_data)
{
stock S;
GtkWidget *nom,*type,*reference,*quantite,*jour,*mois,*annee,*error;
nom=lookup_widget(button,"nom");
if (toggle==1)
{strcpy(S.type,"Biologique");}
else
strcpy(S.type,"Industriel");
reference=lookup_widget(button,"ref");
quantite=lookup_widget(button,"quant");
jour=lookup_widget(button,"Jourd");
mois=lookup_widget(button,"moisd");
annee=lookup_widget(button,"anneed");
strcpy(S.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(S.reference,gtk_entry_get_text(GTK_ENTRY(reference)));
S.quantite=atoi(gtk_entry_get_text(GTK_ENTRY(quantite)));
S.d.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
S.d.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
S.d.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
error=lookup_widget(button,"add");
ajouter(S);
gtk_label_set_text(GTK_LABEL(error),"Ajout avec succés");
}


void
on_chercher_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
char ref[50];
GtkWidget *treeview,*filter,*message;
treeview=lookup_widget(button,"treeview1b");
filter=lookup_widget(button,"refch");
strcpy(ref,gtk_entry_get_text(GTK_ENTRY(filter)));
chercher(treeview,ref);
message=lookup_widget(button,"search");
gtk_label_set_text(GTK_LABEL(message),"Voila le produit souhaitee!");
}





void
on_supprimer_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
stock x;
GtkWidget *reference,*label1;

reference=lookup_widget(button,"refch");
strcpy(x.reference,gtk_entry_get_text(GTK_ENTRY(reference)));
label1=lookup_widget(button,"delete");
supprimer(x.reference);
gtk_label_set_text(GTK_LABEL(label1),"SUPPRESSION AVEC SUCCES!");
}


void
on_modifier_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
stock x;
char ref[50];

GtkWidget *nom,*type,*reference,*quantite,*jour,*mois,*annee,*label,*filter;

nom=lookup_widget(button,"nom2");
type=lookup_widget(button,"combobox1");
reference=lookup_widget(button,"ref2");
quantite=lookup_widget(button,"quant2");
jour=lookup_widget(button,"jour2");
mois=lookup_widget(button,"mois2");
annee=lookup_widget(button,"annee2");
label=lookup_widget(button,"edit");
filter=lookup_widget(button,"refch");
strcpy(ref,gtk_entry_get_text(GTK_ENTRY(filter)));
strcpy(x.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(x.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type)));
strcpy(x.reference,gtk_entry_get_text(GTK_ENTRY(reference)));
x.quantite=atoi(gtk_entry_get_text(GTK_ENTRY(quantite)));
x.d.jour=atoi(gtk_entry_get_text(GTK_ENTRY(jour)));
x.d.mois=atoi(gtk_entry_get_text(GTK_ENTRY(mois)));
x.d.annee=atoi(gtk_entry_get_text(GTK_ENTRY(annee)));
modifier(ref,x.nom,x.type,x.reference,x.quantite,x.d.jour,x.d.mois,x.d.annee);
label=lookup_widget(button,"edit");
gtk_label_set_text(GTK_LABEL(label),"modification faite avec succés");
}




void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
	toggle=1;
}

}


void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
	toggle=2;
}
}


void
on_afficher111_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview1b;
GtkWidget *stock;
treeview1b=lookup_widget(button,"treeview1b");
afficher(treeview1b);
}


void
on_actualiser111_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview2b;
GtkWidget *stock;
treeview2b=lookup_widget(button,"treeview2b");
PERDS(treeview2b);
}





void
on_treeview1b_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_treeview2b_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////HEBERGEMENT-IN//////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void
on_BTfoyerrg_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget *p;
    GtkWidget *p1;
    GtkWidget *entry;
    GtkWidget *entry2;
    GtkWidget *labelEtage;
    GtkWidget *labelClasse;

    gtk_widget_hide (SERVICE25);
    wgestion = create_wgestion ();
    p=lookup_widget(wgestion,"treeview_h1");
    p1=lookup_widget(wgestion,"treeview_h2");
    i=0;
    j=0;
    k=0;
    AfficherEtudiant(p,"students.txt");
    AfficherEtudiant1(p1,"students.txt");
    gtk_widget_show (wgestion);

    entry=lookup_widget(wgestion,"entry_saisir_etage");
    gtk_widget_hide (entry);
    entry2=lookup_widget(wgestion,"entry_saisir_classe");
    gtk_widget_hide (entry2);
    labelEtage=lookup_widget(wgestion,"label_etage4");
    gtk_widget_hide (labelEtage);
    labelClasse=lookup_widget(wgestion,"label_classe4");
    gtk_widget_hide (labelClasse);
}


void
on_GestionAcceuil_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
    gtk_widget_show (SERVICE25);
    gtk_widget_destroy (wgestion);
}


void
on_Homme_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_Femme_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_Ajouter_Etudiant_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget *entryPrenom;
    GtkWidget *entryNom;
    GtkWidget *entryID;
    GtkWidget *entryClasse;
    GtkWidget *entryPays;
    GtkWidget *labelPrenom;
    GtkWidget *labelNom;
    GtkWidget *labelID;
    GtkWidget *labelClasse;
    GtkWidget *labelPays;
    GtkWidget *cal1;
    GtkWidget *combobox;
    GtkWidget *labelCombo;
    GtkWidget *existe;
    GtkWidget *success;
    GFile*f=NULL;
    stud s;
    int jj1,mm1,aa1;
    int b=1;
    int room;

    entryPrenom=lookup_widget(wgestion,"entry_prenom");
    entryNom=lookup_widget(wgestion,"entry_nom");
    entryID=lookup_widget(wgestion,"entry_id");
    entryClasse=lookup_widget(wgestion,"entry_classe");
    entryPays=lookup_widget(wgestion,"entry_pays");

    labelPrenom=lookup_widget(wgestion,"label_prenom1");
    labelNom=lookup_widget(wgestion,"label_nom1");
    labelID=lookup_widget(wgestion,"label_id1");
    labelClasse=lookup_widget(wgestion,"label_classe1");
    labelPays=lookup_widget(wgestion,"label_pays1");
    labelCombo=lookup_widget(wgestion,"label_etage1");
    combobox=lookup_widget(wgestion,"combobox_h");
    cal1=lookup_widget(wgestion,"calendar1");
    existe=lookup_widget(wgestion,"label_existant");
    success=lookup_widget(wgestion,"label_succes1");

    strcpy(s.prenom,gtk_entry_get_text(GTK_ENTRY(entryPrenom) ) );
    strcpy(s.nom,gtk_entry_get_text(GTK_ENTRY(entryNom) ) );
    strcpy(s.id,gtk_entry_get_text(GTK_ENTRY(entryID) ) );
    strcpy(s.classe,gtk_entry_get_text(GTK_ENTRY(entryClasse) ) );
    strcpy(s.pays,gtk_entry_get_text(GTK_ENTRY(entryPays) ) );
    if(gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(lookup_widget(wgestion,"Homme")) ))
    {
        strcpy(s.sexe,"Homme");
    }
    if(gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(lookup_widget(wgestion,"Femme")) ))
    {
        strcpy(s.sexe,"Femme");
    }

    gtk_widget_hide (success);

    if(strcmp(s.prenom,"")==0)
    {
        gtk_widget_show (labelPrenom);
        b=0;
    }
    else
    {
        gtk_widget_hide(labelPrenom);
    }
    if(strcmp(s.nom,"")==0)
    {
        gtk_widget_show (labelNom);
        b=0;
    }
    else
    {
        gtk_widget_hide(labelNom);
    }
    if(strcmp(s.id,"")==0)
    {
        gtk_widget_show (labelID);
        b=0;
    }
    else
    {
        gtk_widget_hide(labelID);
    }
    if(strcmp(s.classe,"")==0)
    {
        gtk_widget_show (labelClasse);
        b=0;
    }
    else
    {
        gtk_widget_hide(labelClasse);
    }
    if(strcmp(s.pays,"")==0)
    {
        gtk_widget_show (labelPays);
        b=0;
    }
    else
    {
        gtk_widget_hide(labelPays);
    }
    if(gtk_combo_box_get_active (GTK_COMBO_BOX(combobox))==-1)
    {
        gtk_widget_show (labelCombo);
        b=0;
    }
    else
    {
        gtk_widget_hide(labelCombo);
    }

    if(b==1)
    {
        strcpy(s.etage,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)));
        room =gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget(wgestion,"spinbutton_h")));
        sprintf(s.room,"%d",room);

        gtk_calendar_get_date (GTK_CALENDAR(cal1),
                               &aa1,
                               &mm1,
                               &jj1);
        sprintf(s.date,"%d/%d/%d",jj1,mm1+1,aa1);
        if(exist_etudiant(s.id)==1)
        {
            gtk_widget_show (existe);
        }
        else
        {
            gtk_widget_hide (existe);

            ajouter_etudiant(s);

            gtk_widget_show (success);
        }

        GtkWidget* p=lookup_widget(wgestion,"treeview_h1");

        AfficherEtudiant(p,"students.txt");
    }
}


void
on_Modifier_Etudiant_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
    stud s;

    strcpy(s.id,gtk_label_get_text(GTK_LABEL(lookup_widget(wgestion,"label_id3"))));
    strcpy(s.prenom,gtk_entry_get_text(GTK_ENTRY(lookup_widget(wgestion,"entry_prenom2"))));
    strcpy(s.nom,gtk_entry_get_text(GTK_ENTRY(lookup_widget(wgestion,"entry_nom2"))));
    strcpy(s.classe,gtk_entry_get_text(GTK_ENTRY(lookup_widget(wgestion,"entry_classe2"))));
    strcpy(s.pays,gtk_entry_get_text(GTK_ENTRY(lookup_widget(wgestion,"entry_pays2"))));

    supprimer_etudiant(s.id);
    ajouter_etudiant(s);

    AfficherEtudiant(lookup_widget(wgestion,"treeview_h1"),"students.txt");
    gtk_widget_show(lookup_widget(wgestion,"label_succes2"));

}


void
on_treeview_h1_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
    gchar *prenom;
    gchar *nom;
    gchar *id;
    gchar *classe;
    gchar *pays;
    gchar *etage;
    gchar *room;
    gchar *sexe;
    gchar *date;
    int x;
    GtkTreeModel     *model;
    GtkTreeIter iter;
    GtkWidget *p=lookup_widget(wgestion,"treeview_h1");
    GtkTreeSelection *selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
    if (gtk_tree_selection_get_selected(selection, &model, &iter))
    {
        gtk_widget_hide(lookup_widget(wgestion,"label_succes2"));

        gtk_tree_model_get (model,&iter,0,&prenom,1,&nom,2,&id,3,&classe,4,&pays,5,&etage,6,&room,7,&sexe,8,&date,-1);

        gtk_entry_set_text(GTK_ENTRY(lookup_widget(wgestion,"entry_prenom2")),prenom);
        gtk_entry_set_text(GTK_ENTRY(lookup_widget(wgestion,"entry_nom2")),nom);
        gtk_entry_set_text(GTK_ENTRY(lookup_widget(wgestion,"entry_classe2")),classe);
        gtk_entry_set_text(GTK_ENTRY(lookup_widget(wgestion,"entry_pays2")),pays);

        GtkWidget* msgID=lookup_widget(wgestion,"label_id3");
        GtkWidget* msg1=lookup_widget(wgestion,"label_modifier");
        gtk_label_set_text(GTK_LABEL(msgID),id);
        gtk_widget_show(msgID);
        gtk_widget_show(msg1);
        gtk_widget_show(lookup_widget(wgestion,"Modifier"));
        gtk_notebook_prev_page(GTK_NOTEBOOK(lookup_widget(wgestion,"notebook_h")));
    }
}


void
on_Supprimer_Etudiant_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkTreeModel     *model;
    GtkTreeSelection *selection;
    GtkTreeIter iter;
    GtkWidget* p;
    GtkWidget *label;
    gchar* id;
    label=lookup_widget(wgestion,"label_selectionner");
    p=lookup_widget(wgestion,"treeview_h1");

    selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
    if (gtk_tree_selection_get_selected(selection, &model, &iter))
    {
        gtk_tree_model_get (model,&iter,0,&id,-1);
        gtk_list_store_remove(GTK_LIST_STORE(model),&iter);//supprimer la ligne du treeView

        supprimer_etudiant(id);// supprimer la ligne du fichier

        gtk_widget_hide (label);
    }
    else
    {
        gtk_widget_show (label);
    }
}


void
on_Chercher_Etudiant_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget *p1;
    GtkWidget *entry;
    GtkWidget *entry2;
    GtkWidget *labelEtage;
    GtkWidget *labelClasse;
    GtkWidget *nbResultat;
    GtkWidget *message;
    char etage[30];
    char classe[30];
    char chnb[30];
    int nb,xe=0,xc=0;

    entry=lookup_widget(wgestion,"entry_saisir_etage");
    labelEtage=lookup_widget(wgestion,"label_saisir_etage");
    p1=lookup_widget(wgestion,"treeview_h2");
    strcpy(etage,gtk_entry_get_text(GTK_ENTRY(entry)));

    entry2=lookup_widget(wgestion,"entry_saisir_classe");
    labelClasse=lookup_widget(wgestion,"label_saisir_classe");
    p1=lookup_widget(wgestion,"treeview_h2");
    strcpy(classe,gtk_entry_get_text(GTK_ENTRY(entry2)));

    if(gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(lookup_widget(wgestion,"check_etage")) ))
    {
        xe=1;
    }
    if(gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(lookup_widget(wgestion,"check_classe")) ))
    {
        xc=1;
    }

    nb=ChercherEtudiant(p1,"students.txt",etage,classe,xe,xc);

    sprintf(chnb,"%d",nb);
    nbResultat=lookup_widget(wgestion,"label_nb");
    message=lookup_widget(wgestion,"label_resultat");
    gtk_label_set_text(GTK_LABEL(nbResultat),chnb);

    gtk_widget_show (nbResultat);
    gtk_widget_show (message);
}


void
on_check_etage_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
    GtkWidget *entry;
    GtkWidget *labelEtage;
    entry=lookup_widget(wgestion,"entry_saisir_etage");
    labelEtage=lookup_widget(wgestion,"label_etage4");

    if(gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(lookup_widget(wgestion,"check_etage")) ))
    {
        gtk_widget_show (entry);
        gtk_widget_show (labelEtage);
    }

    else
    {
        gtk_widget_hide (entry);
        gtk_widget_hide (labelEtage);
    }
}


void
on_check_classe_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget *entry2;
    GtkWidget *labelClasse;
    entry2=lookup_widget(wgestion,"entry_saisir_classe");
    labelClasse=lookup_widget(wgestion,"label_classe4");

    if(gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(lookup_widget(wgestion,"check_classe")) ))
    {
        gtk_widget_show (entry2);
        gtk_widget_show (labelClasse);
    }

    else
    {
        gtk_widget_hide (entry2);
        gtk_widget_hide (labelClasse);
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////HEBERGEMENT-OUT/////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////NUTRISIONNISTE-IN////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void
on_BTnutrig_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *p;
GtkWidget *p1;
GtkWidget *entry;
GtkWidget *entry2;
GtkWidget *labelid;
GtkWidget *labeldate;
gtk_widget_hide (SERVICE25);
gestion = create_gestion ();
p=lookup_widget(gestion,"treeview1r");
p1=lookup_widget(gestion,"treeview2r");
i=0;
j=0;
k=0;
AfficherMenu(p,"Menu.txt");
AfficherMenu1(p1,"Menu.txt");
gtk_widget_show (gestion);

entry=lookup_widget(gestion,"entry_idc");
gtk_widget_hide (entry);
entry2=lookup_widget(gestion,"entry_datec");
gtk_widget_hide (entry2);
labelid=lookup_widget(gestion,"label_idc");
gtk_widget_hide (labelid);
labeldate=lookup_widget(gestion,"label_datec");
gtk_widget_hide (labeldate);
}


void
on_radiobutton1r_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_radiobutton2r_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_radiobutton3r_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_Ajouter_Menu_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
Menu M;
GtkWidget *existe;
GtkWidget *succes;
GtkWidget *combobox;
GtkWidget *spin;
int a;

existe=lookup_widget(gestion,"label_existant_r");
succes=lookup_widget(gestion,"label_succes1r");
int aa,jj,mm;

strcpy(M.id,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestion,"entry_id_r"))));
strcpy(M.entree,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestion,"entry_entree"))));
strcpy(M.dessert,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestion,"entry_dessert"))));
if(gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(lookup_widget(gestion,"radiobutton1r")) )){
strcpy(M.salade,"Cesar");}
if(gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(lookup_widget(gestion,"radiobutton2r")) )){
strcpy(M.salade,"Mechouia");}
if(gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(lookup_widget(gestion,"radiobutton3r")) )){
strcpy(M.salade,"Tunisienne");}
strcpy(M.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(lookup_widget(gestion,"combobox1r"))));

spin = lookup_widget(gestion,"spinbutton1r");

a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin));

sprintf(M.date,"%d",a);


if(exist_menu(M.id)==1)
        {

				  gtk_widget_show (existe);
        }
        else {
						  gtk_widget_hide (existe);
                ajouter_menu(M);

						  gtk_widget_show (succes);
		
	GtkWidget* p=lookup_widget(gestion,"treeview1r");

        AfficherMenu(p,"Menu.txt");
        }
}


void
on_Modifier_Menu_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
	Menu M;

        strcpy(M.id,gtk_label_get_text(GTK_LABEL(lookup_widget(gestion,"label_id3_r"))));
        strcpy(M.entree,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestion,"entry_entree2"))));
	strcpy(M.salade,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestion,"entry_salade2"))));
        strcpy(M.dessert,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestion,"entry_dessert2"))));
	strcpy(M.type,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestion,"entry_type2"))));
	strcpy(M.date,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestion,"entry_date2_r"))));
	
        

        supprimer_menu(M.id);
        ajouter_menu(M);
	 
        AfficherMenu(lookup_widget(gestion,"treeview1r"),"Menu.txt");
		gtk_widget_show(lookup_widget(gestion,"label_succes2r"));
}


void
on_treeview1r_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	gchar *id;
        gchar *entree;
        gchar *salade;
        gchar *dessert;
        gchar *type;
	gchar *date;
        int x;
        GtkTreeModel     *model;
        GtkTreeIter iter;
        GtkWidget *p=lookup_widget(gestion,"treeview1r");
        GtkTreeSelection *selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {
		gtk_widget_hide(lookup_widget(gestion,"label_succes2r"));
		
                gtk_tree_model_get (model,&iter,0,&id,1,&entree,2,&salade,3,&dessert,4,&type,5,&date,-1); 
		
                //gtk_entry_set_text(GTK_ENTRY(lookup_widget(gestion,"entry_id2")),id);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(gestion,"entry_entree2")),entree);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(gestion,"entry_salade2")),salade);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(gestion,"entry_dessert2")),dessert);



                GtkWidget* msgID=lookup_widget(gestion,"label_id3_r");
                GtkWidget* msg1=lookup_widget(gestion,"label_modifier_r");
                gtk_label_set_text(GTK_LABEL(msgID),id);
                gtk_widget_show(msgID);
                gtk_widget_show(msg1);
                gtk_widget_show(lookup_widget(gestion,"Modifier_Menu"));
                gtk_notebook_prev_page(GTK_NOTEBOOK(lookup_widget(gestion,"notebook1r")));
        }
}


void
on_checkbutton1r_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
GtkWidget *entry;
GtkWidget *labelid;
entry=lookup_widget(gestion,"entry_idc");
labelid=lookup_widget(gestion,"label_idc");

if(gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(lookup_widget(gestion,"checkbutton1r")) )){
gtk_widget_show (entry);
gtk_widget_show (labelid);}

else{gtk_widget_hide (entry);
gtk_widget_hide (labelid);}
}


void
on_checkbutton2r_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
GtkWidget *entry2;
GtkWidget *labeldate;
entry2=lookup_widget(gestion,"entry_datec");
labeldate=lookup_widget(gestion,"label_datec");

if(gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(lookup_widget(gestion,"checkbutton2r")) )){
gtk_widget_show (entry2);
gtk_widget_show (labeldate);}

else{gtk_widget_hide (entry2);
gtk_widget_hide (labeldate);}
}


void
on_Supprimer_Menu_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkTreeModel     *model;
        GtkTreeSelection *selection;
        GtkTreeIter iter;
        GtkWidget* p;
        GtkWidget *label;
        gchar* id;
        label=lookup_widget(gestion,"label_selectionner_r");
        p=lookup_widget(gestion,"treeview1r");




        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {  gtk_tree_model_get (model,&iter,0,&id,-1);
           gtk_list_store_remove(GTK_LIST_STORE(model),&iter);

           supprimer_menu(id);

           gtk_widget_hide (label);}
	else{
                gtk_widget_show (label);
        }
}


void
on_Chercher_Menu_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *p1;
GtkWidget *entry;
GtkWidget *entry2;
GtkWidget *labeldate;
GtkWidget *labelid;
GtkWidget *nbResultat;
GtkWidget *message;
char id[50];
char date[50];
char chnb[30];
int nb;
int xm=0,xn=0;
entry=lookup_widget(gestion,"entry_idc");
labelid=lookup_widget(gestion,"label_idc");
p1=lookup_widget(gestion,"treeview2r");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(entry)));

entry2=lookup_widget(gestion,"entry_datec");
labelid=lookup_widget(gestion,"label_datec");
p1=lookup_widget(gestion,"treeview2r");
strcpy(date,gtk_entry_get_text(GTK_ENTRY(entry2)));

if(gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(lookup_widget(gestion,"checkbutton1r")) )){
xm=1;}
if(gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(lookup_widget(gestion,"checkbutton2r")) )){
xn=1;}



nb=ChercherMenu(p1,"Menu.txt",id,date,xm,xn);

sprintf(chnb,"%d",nb);
nbResultat=lookup_widget(gestion,"label_nbr");
message=lookup_widget(gestion,"label_resultatr");
gtk_label_set_text(GTK_LABEL(nbResultat),chnb);

gtk_widget_show (nbResultat);
gtk_widget_show (message);
}


void
on_Meilleur_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
FILE* f;
FILE* fm;
int a,b,na,nb;
float c,nc=1000.00;
  int l;
    char id[50];
    char date[50];
    char type[50];
    char entree[50];
    char salade[50];
    char dessert[50];
   
char text[15];
char msg[100]="le meilleur menu est ";
GtkWidget *sortie;
sortie=lookup_widget(gestion,"label_meilleur");
f=fopen("dechets.txt","r");
while(fscanf(f,"%d %d %f\n",&a,&b,&c)!=EOF){

  if (nc>c){nc=c;
  nb=b;
  na=a;                 }
}
sprintf(text,"%d",na);
fm=fopen("Menu.txt","r");

while(fscanf(fm,"%s %s %s %s %s %s\n",id,entree,salade,dessert,type,date)!=EOF){
   



if (strcmp(type,"Petit_dej")==0){l=1;}
else if (strcmp(type,"Dejeuner")==0){l=2;}
else if (strcmp(type,"Dinner")==0){l=3;}




if ((strcmp(date,text)==0) && (nb==l)){ 

strcat(msg,id);
 gtk_label_set_text(GTK_LABEL(sortie),msg);
}
}
fclose(fm);
fclose(f);
}


void
on_Retour_r_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show (SERVICE25);
gtk_widget_destroy (gestion);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////NUTRISIONNISTE-OUT///////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void
on_buttonAjouter_clicked               (GtkButton       *windowcap,
                                        gpointer         user_data)
{
GtkWidget *id, *mar, *pos, *entryid, *entrymar, *entrypos, *entryty, *entryetat, *entryval, *fail, *success, *verif, *p, *p1, *p2, *p3;
Capteur C;

//les labels
id=lookup_widget(windowcap,"labelid");
mar=lookup_widget(windowcap,"labelma");
pos=lookup_widget(windowcap,"labelpos");
success=lookup_widget(windowcap,"labelsucess");
fail=lookup_widget(windowcap,"labelfail");
verif=lookup_widget(windowcap,"labelverif");

//entries
entryid=lookup_widget(windowcap,"EntryIdentifiant");
entrymar=lookup_widget(windowcap,"EntryMarque");
entrypos=lookup_widget(windowcap,"EntryPosition");
entryetat=lookup_widget(windowcap,"spinbuttonetat");
entryval=lookup_widget(windowcap,"spinbuttonvaleur");
entryty=lookup_widget(windowcap,"ComboBoxEntryType");

//Récuperation de l'identifiant & controle de saisie
strcpy(C.identifiant, gtk_entry_get_text(GTK_ENTRY(entryid)));
if(strcmp(C.identifiant,"")==0){
gtk_widget_show(id);
gtk_widget_show(verif);
}
else
{
gtk_widget_set_visible(id,FALSE);
gtk_widget_set_visible(verif,FALSE);
}

//Récuperation de la marque & controle de saisie
strcpy(C.marque, gtk_entry_get_text(GTK_ENTRY(entrymar)));
if(strcmp(C.marque,"")==0){
gtk_widget_show(mar);
gtk_widget_show(verif);
}
else
{
gtk_widget_set_visible(mar,FALSE);
gtk_widget_set_visible(verif,FALSE);
}
//Récuperation de la position & controle de saisie
strcpy(C.position, gtk_entry_get_text(GTK_ENTRY(entrypos)));
if(strcmp(C.position,"")==0){
gtk_widget_show(pos);
gtk_widget_show(verif);
}
else
{
gtk_widget_set_visible(pos,FALSE);
gtk_widget_set_visible(verif,FALSE);
}
//Récuperation du type 
strcpy(C.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(entryty)));
//Récuperation de la valeur
C.valeur=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entryval));

//Récuperation de l'état
C.etat=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entryetat));



if(gtk_widget_get_visible(id)==FALSE && gtk_widget_get_visible(mar)==FALSE && gtk_widget_get_visible(pos)==FALSE && gtk_widget_get_visible(verif)==FALSE){
if(capteur_exist(C.identifiant)==1){
gtk_widget_set_visible(success,FALSE);
gtk_widget_show(fail);
}else{
ajouter_capteur(C);
//mise à jour du treeview
p=lookup_widget(windowcap,"treeview1n");
Capteurtree(p,"capteurs.txt");
p1=lookup_widget(windowcap,"TreeViewAffichageAlarmante");
Alarmantetree(p1,"alarmantes.txt");
p2=lookup_widget(windowcap,"treeview2n");
ChercherCapteur(p2,"capteurs.txt");
p3=lookup_widget(windowcap,"treeview3n");
Defectueuxtree(p3,"defectueux.txt");
//bien ajouté 
gtk_widget_set_visible(fail,FALSE);
gtk_widget_show(success);
//vider les champs après ajout
gtk_entry_set_text(GTK_ENTRY(entryid),"");
gtk_entry_set_text(GTK_ENTRY(entrymar),"");
gtk_entry_set_text(GTK_ENTRY(entrypos),"");
gtk_spin_button_set_value(GTK_SPIN_BUTTON(entryetat),1);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(entryval),0);
}
}
}


void
on_treeview1n_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_buttonSupprime_clicked              (GtkButton       *windowcap,
                                        gpointer         user_data)
{
GtkTreeSelection *selection;
        GtkTreeModel     *model;
        GtkTreeIter iter;
        GtkWidget* p,*p1, *p2, *p3;
        GtkWidget *suc, *echec;
        gchar* id;
        suc=lookup_widget(windowcap,"labelsucess1");
	echec=lookup_widget(windowcap,"labelfail1");
        p=lookup_widget(windowcap,"treeview1n");
	gtk_widget_set_visible(suc,FALSE);
        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {  
		gtk_widget_set_visible(echec,FALSE);
		gtk_tree_model_get (model,&iter,0,&id,-1);
		gtk_list_store_remove(GTK_LIST_STORE(model),&iter);//supprimer la ligne du treeView

		supprimer_capteur(id);// supprimer la ligne du fichier

           	gtk_widget_show(suc);
		p1=lookup_widget(windowcap,"TreeViewAffichageAlarmante");
		Alarmantetree(p1,"alarmantes.txt");
		p2=lookup_widget(windowcap,"treeview2n");
		ChercherCapteur(p2,"capteurs.txt");
		p3=lookup_widget(windowcap,"treeview3n");
		Defectueuxtree(p3,"defectueux.txt");}
	else
	{
		gtk_widget_show(echec);		
	}
}


void
on_ButtonModifier_clicked              (GtkButton       *windowcap,
                                        gpointer         user_data)
{
GtkTreeSelection *selection;
        GtkTreeModel     *model;
        GtkTreeIter iter;
        gchar* id;
GtkWidget *entryid, *entrymar, *entrypos, *ty, *entryetat, *entryval, *fail, *success, *select, *verif1, *p, *p1, *p2, *p3;
Capteur C;

//les labels
success=lookup_widget(windowcap,"labelsuccess2");
fail=lookup_widget(windowcap,"labelfail2");
select=lookup_widget(windowcap,"labelselection");
verif1=lookup_widget(windowcap,"labelverif1");
//entries
entryid=lookup_widget(windowcap,"EntryId1");
entrymar=lookup_widget(windowcap,"EntryMa1");
entrypos=lookup_widget(windowcap,"EntryPos1");
entryetat=lookup_widget(windowcap,"spinbuttoneta");
entryval=lookup_widget(windowcap,"spinbuttonval");
ty=lookup_widget(windowcap,"ComboBoxEntryt1");

//Récuperation de l'identifiant & controle de saisie
strcpy(C.identifiant, gtk_entry_get_text(GTK_ENTRY(entryid)));
if(strcmp(C.identifiant,"")==0){
gtk_widget_show(verif1);
}
else
{
gtk_widget_set_visible(verif1,FALSE);
}

//Récuperation de la marque & controle de saisie
strcpy(C.marque, gtk_entry_get_text(GTK_ENTRY(entrymar)));
if(strcmp(C.marque,"")==0){
gtk_widget_show(verif1);
}
else
{
gtk_widget_set_visible(verif1,FALSE);
}
//Récuperation de la position & controle de saisie
strcpy(C.position, gtk_entry_get_text(GTK_ENTRY(entrypos)));
if(strcmp(C.position,"")==0){
gtk_widget_show(verif1);
}
else
{
gtk_widget_set_visible(verif1,FALSE);
}
//Récuperation de la valeur
C.valeur=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entryval));

//Récuperation de l'état
C.etat=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entryetat));

//Récuperation du type
strcpy(C.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(ty)));

if(gtk_widget_get_visible(verif1)==FALSE){
	p=lookup_widget(windowcap,"treeview1n");
        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {  
		gtk_widget_set_visible(select,FALSE);
		gtk_tree_model_get (model,&iter,0,&id,-1);
		if(capteur_exist(C.identifiant)==1 && strcmp(C.identifiant,id)!=0){
		gtk_widget_set_visible(success,FALSE);
		gtk_widget_show(fail);
		}
		else
		{
		modifier_capteur(C,id);
		//mise à jour du treeview
		Capteurtree(p,"capteurs.txt");
		p1=lookup_widget(windowcap,"TreeViewAffichageAlarmante");
		Alarmantetree(p1,"alarmantes.txt");
		p2=lookup_widget(windowcap,"treeview2n");
		ChercherCapteur(p2,"capteurs.txt");
		p3=lookup_widget(windowcap,"treeview3n");
		Defectueuxtree(p3,"defectueux.txt");
		//bien modifié
		gtk_widget_set_visible(fail,FALSE);
		gtk_widget_show(success);
		//vider les champs après modification
		gtk_entry_set_text(GTK_ENTRY(entryid),"");
		gtk_entry_set_text(GTK_ENTRY(entrymar),"");
		gtk_entry_set_text(GTK_ENTRY(entrypos),"");
		gtk_spin_button_set_value(GTK_SPIN_BUTTON(entryetat),1);
		gtk_spin_button_set_value(GTK_SPIN_BUTTON(entryval),0);
		}
	}
	else{
	gtk_widget_show(select);
	}
}
}


void
on_ButtonRechercher_clicked            (GtkButton       *windowcap,
                                        gpointer         user_data)
{
GtkWidget *p, *success, *fail, *id;
gchar *identifiant;
id=lookup_widget(windowcap,"EntryId2");
identifiant=gtk_entry_get_text(GTK_ENTRY(id));
p=lookup_widget(windowcap,"treeview2n");
success=lookup_widget(windowcap,"labelsucess3");
fail=lookup_widget(windowcap,"labelfail3");
if(strcmp(identifiant,"")==0){
ChercherCapteur(p,"capteurs.txt");
gtk_widget_set_visible(success,FALSE);
gtk_widget_show(fail);
}
else{
chercher_capteur(identifiant);
ChercherCapteur(p,"capteurs_recherche.txt");
gtk_widget_set_visible(fail,FALSE);
gtk_widget_show(success);
}
}


void
on_TreeViewAffichageAlarmante_row_activated
                                        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_treeview3n_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_treeviewbbb_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_button5Produittttrup_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview2b;
GtkWidget *stock;
treeview2b=lookup_widget(button,"treeviewbbb");
PERDS(treeview2b);
}


void
on_button5menuuuuuuuuu_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
FILE* f;
FILE* fm;
int a,b,na,nb;
float c,nc=1000.00;
  int l;
    char id[50];
    char date[50];
    char type[50];
    char entree[50];
    char salade[50];
    char dessert[50];
   
char text[15];
char msg[100]="le meilleur menu est ";
GtkWidget *sortie;
sortie=lookup_widget(button,"label200");
f=fopen("dechets.txt","r");
while(fscanf(f,"%d %d %f\n",&a,&b,&c)!=EOF){

  if (nc>c){nc=c;
  nb=b;
  na=a;                 }
}
sprintf(text,"%d",na);
fm=fopen("Menu.txt","r");

while(fscanf(fm,"%s %s %s %s %s %s\n",id,entree,salade,dessert,type,date)!=EOF){
   



if (strcmp(type,"Petit_dej")==0){l=1;}
else if (strcmp(type,"Dejeuner")==0){l=2;}
else if (strcmp(type,"Dinner")==0){l=3;}




if ((strcmp(date,text)==0) && (nb==l)){ 

strcat(msg,id);
 gtk_label_set_text(GTK_LABEL(sortie),msg);
}
}
fclose(fm);
fclose(f);
}


void
on_treeviewnnn_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_Capteursd__fectueuxnnnn_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *p, *p1, *p2, *p3;
GtkWidget *windowdash, *windowcapteur;

windowcapteur= create_WindowGestiondescapteurs();



p3=lookup_widget(button,"treeviewnnn");

Defectueuxtree(p3,"defectueux.txt");
}


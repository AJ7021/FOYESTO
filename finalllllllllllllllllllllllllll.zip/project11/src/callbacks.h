#include <gtk/gtk.h>
  GtkWidget *SERVICE25;
  GtkWidget *wgestion;
  GtkWidget *gestion;
typedef struct stud stud;
struct stud{
char prenom[30];
char nom[30];
char id[30];
char classe[30];
char pays[30];
char etage[30];
char room[10];
char sexe[30];
char date[30];
};

typedef struct Menu Menu;
struct Menu {
    char id[50];
    char date[50];
    char type[50];
    char entree[50];
    char salade[50];
    char dessert[50];
};

int x,i,j,k;

void
on_ajout_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_chercher_clicked                    (GtkButton       *button,
                                        gpointer         user_data);



void
on_modifier_clicked                    (GtkButton       *button,
                                        gpointer         user_data);



void
on_supprimer_clicked                   (GtkButton       *button,
                                        gpointer         user_data);


void
on_Continue12_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_CONTINUEEEtachemohseb_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_Cause3_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Cause1_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Lundi5_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_Jeudi5_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Mercredi5_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Samedi5_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Cause2_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_Vendredi5_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Mardi5_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_BTtechnrg_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_BTRESRTrg_clicked                   (GtkButton       *button,
                                        gpointer         user_data);
void
on_BTetudiantrg_clicked                (GtkButton       *button,
                                        gpointer         user_data);
void
on_Home152_clicked                     (GtkButton       *button,
                                        gpointer         user_data);
void
on_HOMELOGser_clicked                  (GtkButton       *button,
                                        gpointer         user_data);
void
on_HOMESMARTES_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5LOGS_clicked                 (GtkButton       *button,
                                        gpointer         user_data);
void
on_adwelcome_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_LOGIN25_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_loginSE_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_gestionSE_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_D__connexionSE_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_AjouterSE_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_ModifierSE_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_SupprimerSE_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_RechercheSE_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_ValiderSE_clicked                   (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_RetourSE_clicked                    (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_afficher_clicked                    (GtkWidget       *objet,
                                        gpointer        user_data);

void
on_capteurSE_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_actualiser_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_save_clicked                        (GtkButton       *objet,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_valider1_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_save1_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour11_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_valider212_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour1111_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1Vmodifier_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2R_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview3_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficherBT4_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifierpartreevi_clicked           (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_supprimerpartree_clicked            (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_afficher111_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_actualiser111_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeview4_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeview1b_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeview2b_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////HEBERGEMENT-IN//////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void
on_BTfoyerrg_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_GestionAcceuil_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_Homme_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Femme_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Ajouter_Etudiant_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_Modifier_Etudiant_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview_h1_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_Supprimer_Etudiant_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_Chercher_Etudiant_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_check_etage_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_check_classe_clicked                (GtkButton       *button,
                                        gpointer         user_data);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////HEBERGEMENT-OUT/////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////NUTRITIONNISTE-IN////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void
on_BTnutrig_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1r_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2r_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton3r_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Ajouter_Menu_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_Modifier_Menu_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1r_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_Supprimer_Menu_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton1r_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2r_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Chercher_Menu_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_Meilleur_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_Retour_r_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////NUTRITIONNISTE-OUT///////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void
on_buttonAjouter_clicked               (GtkButton       *windowcap,
                                        gpointer         user_data);

void
on_treeview1n_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonSupprime_clicked              (GtkButton       *windowcap,
                                        gpointer         user_data);

void
on_ButtonModifier_clicked              (GtkButton       *windowcap,
                                        gpointer         user_data);

void
on_ButtonRechercher_clicked            (GtkButton       *windowcap,
                                        gpointer         user_data);

void
on_TreeViewAffichageAlarmante_row_activated
                                        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeview3n_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeviewbbb_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button5Produittttrup_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5menuuuuuuuuu_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeviewnnn_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_Capteursd__fectueuxnnnn_clicked     (GtkButton       *button,
                                        gpointer         user_data);

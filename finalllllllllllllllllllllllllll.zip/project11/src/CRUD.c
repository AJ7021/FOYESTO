#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include "callbacks.h"
#include<string.h>


void ajouter_etudiant(stud s){
FILE*f=NULL;
f=fopen("students.txt","a+");//(+) creation du fichier sil nexsite pas
fprintf(f,"%s %s %s %s %s %s %s %s %s\n",s.prenom,s.nom,s.id,s.classe,s.pays,s.etage,s.room,s.sexe,s.date);
fclose(f);
}


int exist_etudiant(char*id){
FILE*f=NULL;
stud s;
f=fopen("students.txt","r");
while(fscanf(f,"%s %s %s %s %s %s %s %s %s\n",s.prenom,s.nom,s.id,s.classe,s.pays,s.etage,s.room,s.sexe,s.date)!=EOF){
if(strcmp(s.id,id)==0)return 1;
}
fclose(f);
return 0;
}


void supprimer_etudiant(char*id){
FILE*f=NULL;
FILE*f1=NULL;
stud s;
f=fopen("students.txt","r");//9dim

f1=fopen("ancien.txt","w+");//3maltt l copie jdidaa
while(fscanf(f,"%s %s %s %s %s %s %s %s %s\n",s.prenom,s.nom,s.id,s.classe,s.pays,s.etage,s.room,s.sexe,s.date)!=EOF){
if(strcmp(id,s.id)!=0)fprintf(f1,"%s %s %s %s %s %s %s %s %s\n",s.prenom,s.nom,s.id,s.classe,s.pays,s.etage,s.room,s.sexe,s.date);
}
fclose(f);
fclose(f1);
remove("students.txt");
rename("ancien.txt","students.txt");
}















#include <gtk/gtk.h>
typedef struct
{
int jour;
int mois;
int annee;
}date;



typedef struct 
{
char nom[50];
char type[150];
char reference[20];
int quantite;
date d;
}stock;


void chercher(GtkWidget *list,char ref[]);
void ajouter(stock S );
void modifier(char ref[],char NOM[],char TYPE[],char REF[],int QUANT,int JOUR,int MOIS,int ANNEE);
void supprimer(char ref[]);
void afficher(GtkWidget *list);
void PERDS(GtkWidget *list);

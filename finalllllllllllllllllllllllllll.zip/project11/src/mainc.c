int main()
{
 ParticipantSE p;
 int n ,choix ;
 char utilisateurSe,CIN;

 do
 {
    do
        {
            printf("si on taper 1 on va ajouter un participant \n si on taper 2 on va modifier un participant \n si on taper 3 on va recherche un a participant \n si on taper 4 on va supprimer un partcipant \n si on taper 5 on va ajouter un participant \n si on taper 0 on va quitter\n");
         scanf("%d",&choix);
    }
    while (choix <0 ||choix >5);
        switch (choix)
    {
case 1:
            n=verif(p,utilisateurSe);
            printf("tapez 1 pour faire une autre tache\n");
            scanf("%i",&choix);
            break;
case 2:
            printf("donner un CIN pour modifier \n");
            fflush(stdin);
            scanf("%i",&CIN);
            ParticipantSE_modifier(p,utilisateurSe);
            printf("tapez 1 pour faire une autre tache\n");
            scanf("%i",&choix);
            break;
case 3:
            printf("donner un CIN pour supprimer\n");
            scanf("%i",&CIN);
            ParticipantSE_supprimer(p,utilisateurSe);
            printf("tapez 1 pour faire une autre tache\n");
            scanf("%i",&choix);
            break;
case 4:
            printf("donner un CIN pour rechercher");
            scanf("%i",&CIN);
            ParticipantSE_recherche(p,utilisateurSe,CIN);
            printf("tapez 1 pour faire une autre tache\n");
            scanf("%i",&choix);
            break;
 default:
            printf("verifier votre choix");
            break;
   }
    }
    while(choix!=0);
    return 0;

   }


void ParticipantSE_recherche(ParticipantSE p,char utilisateurSe[],char CIN[]);
{
char ch1[20],ch2[20],ch3[20],ch4[20],ch5[20],ch6[20];
    int nbrE,p;
    FILE* f =fopen("utilisateurSe.txt","r");
    if (f!=NULL)
    {
        do
        {
            fscanf(f, "%s %s %s %s %s %s\n",ch1,ch2,ch3,ch4,ch5,ch6);

        }
        while ((feof(f))||(strcmp(prenom,ch)!=0));

    }
    fclose(f);
}
void participentSE_supprimer(participentSE p, char utilisateurSe[]);

{
participentSE p;


FILE*f1;
FILE*f2;

f1=fopen("utilisateurSe.txt","r");
f2=fopen("utilisateurSe.txt","w");
if (f1!=NULL)
{


fprintf(f1,"%s %s %s %s %s %s \n",CIN,motpasse,email,nom,prenom,ville);
{

if(strcmp(E.id,id)!=0)
{
fprintf(f2,"%s %s %s %s %s %s \n",CIN,motpasse,email,nom,prenom,ville);
}
}
fclose(f1);
  fclose(f2);
  remove("utilisateurSe.txt");
  rename("utilisateurSe.txt","utilisateurSe.txt");

}

}
void participentSE_modifier(participentSE p, char utilisateurSe[]);
{

participentSE p;

FILE*f;
FILE*f1;
f=fopen("utilisateurSe.txt","r");
f1=fopen("utilisateurSe.txt","w");
while(fscanf(f,"%s %s %s %s %s %s\n",p.CIN,p.motpasse,p.email,p.nom,p.prenom,p.ville)!=EOF)
{
if(strcmp(p.CIN,CIN)==0)
{
fprintf(f1,"%s %s %s %s %s %s\n",p.CIN,p.motpasse,p.email,p.nom,p.prenom,p.ville);

}
else
{
fprintf(f1,"%s %s %s %s %s %s\n",p.CIN,p.motpasse,p.email,p.nom,p.prenom,p.ville);
}
}
fclose(f);
fclose(f1);
remove("utilisateurSe.txt");
rename("utilisateurSe.txt","utilisateurSe.txt")

}
void participentSE_affiche( participentSE p, char utilisateurSe[]);
{
participentSE p;
FILE*f;
f=fopen("utilisateurSe.txt","r");
printf(f,"%s %s %s %s %s %s\n",p.CIN,p.motpasse,p.email,p.nom,p.prenom,p.ville);

}
 void participentSE_ajouter(participentSE p, char utilisateurSe[]);
{

int trouve=-1;
FILE *f=NULL;

char ch1[20];
char ch2[20];
char ch3[20];
char ch4[20];
char ch5[20];
char ch6[20];
f=fopen("utilisateurSe.txt","a+");
if (f!=NULL)
{
printf("cin?");
scanf ("%s",p.CIN);
printf("password?");
scanf ("%s",p.password);
printf("nom?");
scanf ("%s",p.nom);
printf("prenom?");
scanf ("%s",p.password);
printf("mail?");
scanf ("%s",p.mail);
printf("adresse");
scanf("%s",p.adresse)

fclose(f);

}
else
printf("\n not found");




}



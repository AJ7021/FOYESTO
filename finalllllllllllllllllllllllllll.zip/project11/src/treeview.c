#include <stdlib.h>
#include <stdio.h>
#include<string.h>
#include <gtk/gtk.h>
#include "interface.h"
#include "callbacks.h"
#include "treeview.h"

GtkListStore *adstore;
GtkTreeViewColumn *adcolumn;
GtkCellRenderer *cellad;
FILE *f;

void AfficherMenu(GtkWidget* treeview1r,char*l)
{

	Menu M;


        
        adstore = gtk_list_store_new(6,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
				     G_TYPE_STRING,
				     G_TYPE_STRING,
                                     G_TYPE_STRING);
       
        f=fopen(l,"r");
while(fscanf(f,"%s %s %s %s %s %s \n",M.id,M.entree,M.salade,M.dessert,M.type,M.date)!=EOF)
        {GtkTreeIter pIter;

       
         gtk_list_store_append(adstore, &pIter);
         
         gtk_list_store_set(adstore, &pIter,
                            0,M.id,
                            1,M.entree,
                            2,M.salade,
                            3,M.dessert,
			    4,M.type,
			    5,M.date,
                            -1);}
        fclose(f);

	
if(i==0)
	{cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("ID",
                                                            cellad,
                                                            "text", 0,
                                                            NULL);


        
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1r), adcolumn);


	
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("ENTREE",
                                                            cellad,
                                                            "text", 1,
                                                            NULL);
	
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1r), adcolumn);

	
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("SALADE",
                                                            cellad,
                                                            "text", 2,
                                                            NULL);
	
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1r), adcolumn);

	
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("DESSERT",
                                                            cellad,
                                                            "text", 3,
                                                            NULL);
	
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1r), adcolumn);

	
	cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("TYPE",
                                                            cellad,
                                                            "text", 4,
                                                            NULL);

	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1r), adcolumn);

	
	cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("DATE",
                                                            cellad,
                                                            "text", 5,
                                                            NULL);

	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1r), adcolumn);
	i++;}


 	gtk_tree_view_set_model ( GTK_TREE_VIEW (treeview1r),
                                  GTK_TREE_MODEL(adstore)  );

}



void AfficherMenu1(GtkWidget* treeview1r,char*l)
{

Menu M;


        
        adstore = gtk_list_store_new(6,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
				     G_TYPE_STRING,
				     G_TYPE_STRING,
                                     G_TYPE_STRING);
        
        f=fopen(l,"r");
while(fscanf(f,"%s %s %s %s %s %s \n",M.id,M.entree,M.salade,M.dessert,M.type,M.date)!=EOF)
        {GtkTreeIter pIter;
	
        
         gtk_list_store_append(adstore, &pIter);
         
         gtk_list_store_set(adstore, &pIter,
                            0,M.id,
                            1,M.entree,
                            2,M.salade,
                            3,M.dessert,
			    4,M.type,
			    5,M.date,
                            -1);}
        fclose(f);

	
if(j==0)
	{cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("ID",
                                                            cellad,
                                                            "text", 0,
                                                            NULL);


        
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1r), adcolumn);


	
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("ENTREE",
                                                            cellad,
                                                            "text", 1,
                                                            NULL);
	
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1r), adcolumn);

	
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("SALADE",
                                                            cellad,
                                                            "text", 2,
                                                            NULL);
	
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1r), adcolumn);

	
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("DESSERT",
                                                            cellad,
                                                            "text", 3,
                                                            NULL);
	
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1r), adcolumn);

	 cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("TYPE",
                                                            cellad,
                                                            "text", 4,
                                                            NULL);
	
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1r), adcolumn);

	cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("DATE",
                                                            cellad,
                                                            "text", 5,
                                                            NULL);
	
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1r), adcolumn);	
	
	j++;}


 	gtk_tree_view_set_model ( GTK_TREE_VIEW (treeview1r),
                                  GTK_TREE_MODEL(adstore)  );

}



int ChercherMenu(GtkWidget* treeview1r,char*l,char*id,char*date,int xm,int xn)
{

Menu M;
int nb=0;

       
        adstore = gtk_list_store_new(6,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
				     G_TYPE_STRING,
				     G_TYPE_STRING,
                                     G_TYPE_STRING);
        
        f=fopen(l,"r");
while(fscanf(f,"%s %s %s %s %s %s\n",M.id,M.entree,M.salade,M.dessert,M.type,M.date)!=EOF)
        {
	if(xm==1){
		if(xn==1){
			if(strcmp(id,M.id)==0 && strcmp(date,M.date)==0){ 
				nb++;
	 	 GtkTreeIter pIter;
	         /* Creation de la nouvelle ligne */
	         gtk_list_store_append(adstore, &pIter);
	         /* Mise a jour des donnees */
	         gtk_list_store_set(adstore, &pIter,
	                            0,M.id,
	                            1,M.entree,
	                            2,M.salade,
	                            3,M.dessert,
	                            4,M.type,
	                            5,M.date,
	                            -1);}
		}
		else{
			if(strcmp(id,M.id)==0){
				nb++;
	 	 GtkTreeIter pIter;
	         /* Creation de la nouvelle ligne */
	         gtk_list_store_append(adstore, &pIter);
	         /* Mise a jour des donnees */
	         gtk_list_store_set(adstore, &pIter,
	                            0,M.id,
	                            1,M.entree,
	                            2,M.salade,
	                            3,M.dessert,
	                            4,M.type,
	                            5,M.date,
	                            -1);}
		}
	}
	else{
		if(xn==1){
			if(strcmp(date,M.date)==0){ 
				nb++;
	 	 GtkTreeIter pIter;
	         /* Creation de la nouvelle ligne */
	         gtk_list_store_append(adstore, &pIter);
	         /* Mise a jour des donnees */
	         gtk_list_store_set(adstore, &pIter,
	                            0,M.id,
	                            1,M.entree,
	                            2,M.salade,
	                            3,M.dessert,
	                            4,M.type,
	                            5,M.date,
	                            -1);}
		}
}
}
        fclose(f);

	
if(j==0)
	{cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("ID",
                                                            cellad,
                                                            "text", 0,
                                                            NULL);


        
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1r), adcolumn);


	
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("ENTREE",
                                                            cellad,
                                                            "text", 1,
                                                            NULL);
	
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1r), adcolumn);

	
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("SALADE",
                                                            cellad,
                                                            "text", 2,
                                                            NULL);
	
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1r), adcolumn);

	
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("DESSERT",
                                                            cellad,
                                                            "text", 3,
                                                            NULL);
	
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1r), adcolumn);

	cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("TYPE",
                                                            cellad,
                                                            "text", 4,
                                                            NULL);
	
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1r), adcolumn);

	cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("DATE",
                                                            cellad,
                                                            "text", 5,
                                                            NULL);

	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1r), adcolumn);


	j++;}


 	gtk_tree_view_set_model ( GTK_TREE_VIEW (treeview1r),
                                  GTK_TREE_MODEL(adstore)  );
return nb;
}






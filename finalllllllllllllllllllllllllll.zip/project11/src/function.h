
void ajouter_menu(Menu M);
int exist_menu(char*id);
void supprimer_menu(char*id);



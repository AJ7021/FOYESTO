
#include"verif.h"
#include<stdio.h>
#include <gtk/gtk.h>

int veriff(char CIN1[],char password1[])
{

int trouve=-1;
FILE *f=NULL;

char ch1[20];
char ch2[20];
f=fopen("utilisateurS.txt","r");
if (f!=NULL)
{
while(fscanf(f,"%s %s" ,ch1,ch2)!=EOF)
{
if((strcmp(ch1,CIN1)==0) &&(strcmp(ch2,password1)==0))
trouve=1;
}
fclose(f);
}

return trouve;
}

int veriff1(char NUM1[],char password12[])
{

int trouve=-1;
FILE *f=NULL;

char ch1[20];
char ch2[20];
f=fopen("utilisateurS.txt","r");
if (f!=NULL)
{
while(fscanf(f,"%s %s" ,ch1,ch2)!=EOF)
{
if((strcmp(ch1,NUM1)==0) &&(strcmp(ch2,password12)==0))
trouve=1;
}
fclose(f);
}

return trouve;

}


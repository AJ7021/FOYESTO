#include <stdlib.h>
#include <stdio.h>
#include<string.h>
#include <gtk/gtk.h>
#include "interface.h"
#include "callbacks.h"
#include "tree.h"

GtkListStore *adstore;/*creation du modele de type liste*/
GtkTreeViewColumn *adcolumn;/*visualisation des colonnes*/
GtkCellRenderer *cellad;/*afficheur de cellule(text,image..)*/
FILE *f;

void AfficherEtudiant(GtkWidget* treeview_h1,char*l)
{
stud s;


        /* Creation du modele */
        adstore = gtk_list_store_new(9,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING);
        /* Insertion des elements */
        f=fopen(l,"r");
while(fscanf(f,"%s %s %s %s %s %s %s %s %s\n",s.prenom,s.nom,s.id,s.classe,s.pays,s.etage,s.room,s.sexe,s.date)!=EOF)
        {GtkTreeIter pIter;

         /* Creation de la nouvelle ligne */
         gtk_list_store_append(adstore, &pIter);
         /* Mise a jour des donnees */
         gtk_list_store_set(adstore, &pIter,
                            0,s.prenom,
                            1,s.nom,
                            2,s.id,
                            3,s.classe,
                            4,s.pays,
                            5,s.etage,
                            6,s.room,
                            7,s.sexe,
                            8,s.date,
                            -1);}
        fclose(f);


if(i==0)
	{



        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("PRENOM",
                                                            cellad,
                                                            "text", 0,
                                                            NULL);
	
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_h1), adcolumn);


        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("NOM",
                                                            cellad,
                                                            "text", 1,
                                                            NULL);

	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_h1), adcolumn);


        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("ID",
                                                            cellad,
                                                            "text", 2,
                                                            NULL);

	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_h1), adcolumn);


        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("CLASSE",
                                                            cellad,
                                                            "text", 3,
                                                            NULL);

	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_h1), adcolumn);


        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("PAYS",
                                                            cellad,
                                                            "text", 4,
                                                            NULL);

	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_h1), adcolumn);


        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("ETAGE",
                                                            cellad,
                                                            "text", 5,
                                                            NULL);

	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_h1), adcolumn);


        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("ROOM",
                                                            cellad,
                                                            "text", 6,
                                                            NULL);

	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_h1), adcolumn);


        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("SEXE",
                                                            cellad,
                                                            "text", 7,
                                                            NULL);

	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_h1), adcolumn);


        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("DATE",
                                                            cellad,
                                                            "text", 8,
                                                            NULL);

	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_h1), adcolumn);



	i++;
}


 	gtk_tree_view_set_model ( GTK_TREE_VIEW (treeview_h1),
                                  GTK_TREE_MODEL(adstore)  );

}



void AfficherEtudiant1(GtkWidget* treeview_h1,char*l)
{
stud s;


        /* Creation du modele */
        adstore = gtk_list_store_new(9,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING);
        /* Insertion des elements */
        f=fopen(l,"r");
while(fscanf(f,"%s %s %s %s %s %s %s %s %s\n",s.prenom,s.nom,s.id,s.classe,s.pays,s.etage,s.room,s.sexe,s.date)!=EOF)
        {GtkTreeIter pIter;

         /* Creation de la nouvelle ligne */
         gtk_list_store_append(adstore, &pIter);
         /* Mise a jour des donnees */
         gtk_list_store_set(adstore, &pIter,
                            0,s.prenom,
                            1,s.nom,
                            2,s.id,
                            3,s.classe,
                            4,s.pays,
                            5,s.etage,
                            6,s.room,
                            7,s.sexe,
                            8,s.date,
                            -1);}
        fclose(f);


if(i==0)
	{



        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("PRENOM",
                                                            cellad,
                                                            "text", 0,
                                                            NULL);
	
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_h1), adcolumn);


        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("NOM",
                                                            cellad,
                                                            "text", 1,
                                                            NULL);

	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_h1), adcolumn);


        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("ID",
                                                            cellad,
                                                            "text", 2,
                                                            NULL);

	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_h1), adcolumn);


        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("CLASSE",
                                                            cellad,
                                                            "text", 3,
                                                            NULL);

	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_h1), adcolumn);


        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("PAYS",
                                                            cellad,
                                                            "text", 4,
                                                            NULL);

	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_h1), adcolumn);


        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("ETAGE",
                                                            cellad,
                                                            "text", 5,
                                                            NULL);

	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_h1), adcolumn);


        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("ROOM",
                                                            cellad,
                                                            "text", 6,
                                                            NULL);

	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_h1), adcolumn);


        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("SEXE",
                                                            cellad,
                                                            "text", 7,
                                                            NULL);

	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_h1), adcolumn);


        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("DATE",
                                                            cellad,
                                                            "text", 8,
                                                            NULL);

	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_h1), adcolumn);



	j++;
}


 	gtk_tree_view_set_model ( GTK_TREE_VIEW (treeview_h1),
                                  GTK_TREE_MODEL(adstore)  );

}


int ChercherEtudiant(GtkWidget* treeview_h1,char*l,char*etage,char*classe,int xe,int xc)
{

stud s;
int nb=0;

        //* Creation du modele */
        adstore = gtk_list_store_new(9,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING);
        /* Insertion des elements */
        f=fopen(l,"r");
while(fscanf(f,"%s %s %s %s %s %s %s %s %s\n",s.prenom,s.nom,s.id,s.classe,s.pays,s.etage,s.room,s.sexe,s.date)!=EOF)
        {
	if(xe==1){
		if(xc==1){
			if(strcmp(etage,s.etage)==0 && strcmp(classe,s.classe)==0){ 
				nb++;
	 	 GtkTreeIter pIter;
	         /* Creation de la nouvelle ligne */
	         gtk_list_store_append(adstore, &pIter);
	         /* Mise a jour des donnees */
	         gtk_list_store_set(adstore, &pIter,
	                            0,s.prenom,
	                            1,s.nom,
	                            2,s.id,
	                            3,s.classe,
	                            4,s.pays,
	                            5,s.etage,
	                            6,s.room,
	                            7,s.sexe,
	                            8,s.date,
	                            -1);}
		}
		else{
			if(strcmp(etage,s.etage)==0){
				nb++;
	 	 GtkTreeIter pIter;
	         /* Creation de la nouvelle ligne */
	         gtk_list_store_append(adstore, &pIter);
	         /* Mise a jour des donnees */
	         gtk_list_store_set(adstore, &pIter,
	                            0,s.prenom,
	                            1,s.nom,
	                            2,s.id,
	                            3,s.classe,
	                            4,s.pays,
	                            5,s.etage,
	                            6,s.room,
	                            7,s.sexe,
	                            8,s.date,
	                            -1);}
		}
	}
	else{
		if(xc==1){
			if(strcmp(classe,s.classe)==0){ 
				nb++;
	 	 GtkTreeIter pIter;
	         /* Creation de la nouvelle ligne */
	         gtk_list_store_append(adstore, &pIter);
	         /* Mise a jour des donnees */
	         gtk_list_store_set(adstore, &pIter,
	                            0,s.prenom,
	                            1,s.nom,
	                            2,s.id,
	                            3,s.classe,
	                            4,s.pays,
	                            5,s.etage,
	                            6,s.room,
	                            7,s.sexe,
	                            8,s.date,
	                            -1);}
		}
		
	}
		
		
					
	
	}
        fclose(f);

	/* Creation de la 1ere colonne */
if(j==0)
{
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("PRENOM",
                                                            cellad,
                                                            "text", 0,
                                                            NULL);
	
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_h1), adcolumn);


        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("NOM",
                                                            cellad,
                                                            "text", 1,
                                                            NULL);

	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_h1), adcolumn);


        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("ID",
                                                            cellad,
                                                            "text", 2,
                                                            NULL);

	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_h1), adcolumn);


        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("CLASSE",
                                                            cellad,
                                                            "text", 3,
                                                            NULL);

	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_h1), adcolumn);


        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("PAYS",
                                                            cellad,
                                                            "text", 4,
                                                            NULL);

	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_h1), adcolumn);


        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("ETAGE",
                                                            cellad,
                                                            "text", 5,
                                                            NULL);

	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_h1), adcolumn);


        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("ROOM",
                                                            cellad,
                                                            "text", 6,
                                                            NULL);

	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_h1), adcolumn);


        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("SEXE",
                                                            cellad,
                                                            "text", 7,
                                                            NULL);

	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_h1), adcolumn);


        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("DATE",
                                                            cellad,
                                                            "text", 8,
                                                            NULL);

	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_h1), adcolumn);



	j++;}


 	gtk_tree_view_set_model ( GTK_TREE_VIEW (treeview_h1),
                                  GTK_TREE_MODEL(adstore)  );
return nb;
}





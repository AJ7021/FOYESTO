
void ajouter_etudiant(stud s);
int exist_etudiant(char*id);
void supprimer_etudiant(char*id);


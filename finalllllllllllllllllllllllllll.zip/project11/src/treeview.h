

void AfficherMenu(GtkWidget* treeview1r,char*l);
void AfficherMenu1(GtkWidget* treeview1r,char*l);
int ChercherMenu(GtkWidget* treeview1r,char*l,char*id,char*date,int xm,int xn);

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "capteurs.h"
//fonction ajout
void ajouter_capteur(Capteur C)
{
FILE *f=NULL;
FILE *f1=NULL;
FILE *f2=NULL;
f=fopen("capteurs.txt","a");
if(f == NULL)
{
printf("Impossible d'ouvrir le fichier");
}
else
{
fprintf(f,"%s %s %s %s %d %d\n",C.identifiant,C.marque,C.position,C.type,C.valeur,C.etat);
	if ((C.valeur>=101) && (C.valeur<=201)){
	f1=fopen("alarmantes.txt","a");
	fprintf(f1,"%s %s %s %s %d %d\n",C.identifiant,C.marque,C.position,C.type,C.valeur,C.etat);
	fclose(f1);
	}
	if (C.etat==0){
	f2=fopen("defectueux.txt","a");
	fprintf(f2,"%s %s %s %s %d %d\n",C.identifiant,C.marque,C.position,C.type,C.valeur,C.etat);
	fclose(f2);
	}
fclose(f);
}
}
//fonction suprresion
void supprimer_capteur(char *id)
{
FILE*f=NULL;
FILE*f1=NULL;
Capteur C,C1,C2 ;
f=fopen("capteurs.txt","r");
f1=fopen("ancienscap.txt","w+");
while(fscanf(f,"%s %s %s %s %d %d\n",C.identifiant,C.marque,C.position,C.type,&C.valeur,&C.etat)!=EOF)
{
if(strcmp(id,C.identifiant)!=0)
    fprintf(f1,"%s %s %s %s %d %d\n",C.identifiant,C.marque,C.position,C.type,C.valeur,C.etat);
}
fclose(f);
fclose(f1);
remove("capteurs.txt");
rename("ancienscap.txt","capteurs.txt");
//fichier capteur alarmant
FILE*f3=fopen("alarmantes.txt","r");
FILE*f4=fopen("ancienscap.txt","w+");
while(fscanf(f3,"%s %s %s %s %d %d\n",C.identifiant,C.marque,C.position,C.type,&C.valeur,&C.etat)!=EOF)
{
if(strcmp(C.identifiant,id)!=0)
{
fprintf(f4,"%s %s %s %s %d %d\n",C.identifiant,C.marque,C.position,C.type,C.valeur,C.etat);
}
}
fclose(f3);
fclose(f4);
remove("alarmantes.txt");
rename("ancienscap.txt","alarmantes.txt");
//fichier capteur defectueux
FILE*f5=fopen("defectueux.txt","r");
FILE*f6=fopen("ancienscap.txt","w+");
while(fscanf(f5,"%s %s %s %s %d %d\n",C.identifiant,C.marque,C.position,C.type,&C.valeur,&C.etat)!=EOF)
{
if(strcmp(C.identifiant,id)!=0)
{
fprintf(f6,"%s %s %s %s %d %d\n",C.identifiant,C.marque,C.position,C.type,C.valeur,C.etat);
}
}
fclose(f5);
fclose(f6);
remove("defectueux.txt");
rename("ancienscap.txt","defectueux.txt");

}
//fonction chercher
void chercher_capteur(char * id){
remove("capteurs_recherche.txt");
FILE*f=fopen("capteurs.txt","r");
FILE*f1=fopen("capteurs_recherche.txt","a+");
Capteur C;
while(fscanf(f,"%s %s %s %s %d %d\n",C.identifiant,C.marque,C.position,C.type,&C.valeur,&C.etat)!=EOF)
{
if(strcmp(id,C.identifiant)==0){
fprintf(f1,"%s %s %s %s %d %d\n",C.identifiant,C.marque,C.position,C.type,C.valeur,C.etat);

}
}
fclose(f);
fclose(f1);
}

// fonction modifier
void modifier_capteur(Capteur tempo, char*id ){
//ficher capteur
FILE*f=fopen("capteurs.txt","r");
FILE*f1=fopen("ancienscap.txt","w+");
Capteur C;
while(fscanf(f,"%s %s %s %s %d %d\n",C.identifiant,C.marque,C.position,C.type,&C.valeur,&C.etat)!=EOF)
{
if(strcmp(C.identifiant,id)==0)
{
fprintf(f1,"%s %s %s %s %d %d\n",id,tempo.marque,tempo.position,tempo.type,tempo.valeur,tempo.etat);
}
else{
fprintf(f1,"%s %s %s %s %d %d\n",C.identifiant,C.marque,C.position,C.type,C.valeur,C.etat);
}
}
fclose(f);
fclose(f1);
remove("capteurs.txt");
rename("ancienscap.txt","capteurs.txt");
//fichier capteur alarmant
FILE*f3=fopen("alarmantes.txt","r");
FILE*f4=fopen("ancienscap.txt","w+");

while(fscanf(f3,"%s %s %s %s %d %d\n",C.identifiant,C.marque,C.position,C.type,&C.valeur,&C.etat)!=EOF)
{
if(strcmp(C.identifiant,id)==0)
{
fprintf(f4,"%s %s %s %s %d %d\n",id,tempo.marque,tempo.position,tempo.type,tempo.valeur,tempo.etat);
}
else{
fprintf(f4,"%s %s %s %s %d %d\n",C.identifiant,C.marque,C.position,C.type,C.valeur,C.etat);
}
}
fclose(f3);
fclose(f4);
remove("alarmantes.txt");
rename("ancienscap.txt","alarmantes.txt");
//fichier capteur defectueux
FILE*f5=fopen("defectueux.txt","r");
FILE*f6=fopen("ancienscap.txt","w+");

while(fscanf(f5,"%s %s %s %s %d %d\n",C.identifiant,C.marque,C.position,C.type,&C.valeur,&C.etat)!=EOF)
{
if(strcmp(C.identifiant,id)==0)
{
fprintf(f6,"%s %s %s %s %d %d\n",id,tempo.marque,tempo.position,tempo.type,tempo.valeur,tempo.etat);
}
else{
fprintf(f6,"%s %s %s %s %d %d\n",C.identifiant,C.marque,C.position,C.type,C.valeur,C.etat);
}
}
fclose(f5);
fclose(f6);
remove("defectueux.txt");
rename("ancienscap.txt","defectueux.txt");

}
//fonction changer etat
void changer_etat_capteur(char *id ,int etat)
{
FILE *f=NULL;
FILE *f1=NULL;
Capteur C;
//printf + scanf de : marque , position, type, etat dans tempo

f=fopen("capteurs.txt","r");
f1=fopen("ancienscap.txt","w+");
while (fscanf(f,"%s %s %s %s %d %d\n",C.identifiant,C.marque,C.position,C.type,&C.valeur,&C.etat)!=EOF)
{
if(strcmp(id,C.identifiant)!=0)
{
fprintf(f1,"%s %s %s %s %d %d\n",C.identifiant,C.marque,C.position,C.type,C.valeur,C.etat);
}
else
{
fprintf(f1,"%s %s %s %s %d %d\n",id,C.marque,C.position,C.type,C.valeur,etat);
}

}
fclose(f);
fclose(f1);
remove("capteurs.txt");
rename("ancienscap.txt","capteurs.txt");
}



//fonction exist
int capteur_exist(char*id){
FILE*f=NULL;
Capteur C;
f=fopen("capteurs.txt","r");
while(fscanf(f,"%s %s %s %s %d %d\n",C.identifiant,C.marque,C.position,C.type,&C.valeur,&C.etat)!=EOF)
{
if(strcmp(C.identifiant,id)==0){
return 1;
}
fclose(f);
return 0;
}
}





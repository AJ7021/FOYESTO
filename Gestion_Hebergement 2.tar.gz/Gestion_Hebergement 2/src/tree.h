

void AfficherEtudiant(GtkWidget* treeview_h1,char*l);
void AfficherEtudiant1(GtkWidget* treeview_h1,char*l);
int ChercherEtudiant(GtkWidget* treeview_h1,char*l,char*etage,char*classe,int xe,int xc);

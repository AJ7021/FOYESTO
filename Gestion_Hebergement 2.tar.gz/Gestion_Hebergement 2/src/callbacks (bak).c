#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include <string.h>
#include <stdio.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include"tree.h"
#include"CRUD.h"

void
on_AcceuilGestion_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *p;
GtkWidget *p1;
GtkWidget *entry;
GtkWidget *entry2;
GtkWidget *labelEtage;
GtkWidget *labelClasse;

gtk_widget_hide (wacceuil);
wgestion = create_wgestion ();
p=lookup_widget(wgestion,"treeview_h1");
p1=lookup_widget(wgestion,"treeview_h2");
i=0;
j=0;
k=0;
AfficherEtudiant(p,"students.txt");
AfficherEtudiant1(p1,"students.txt");
gtk_widget_show (wgestion);


entry=lookup_widget(wgestion,"entry_saisir_etage");
gtk_widget_hide (entry);
entry2=lookup_widget(wgestion,"entry_saisir_classe");
gtk_widget_hide (entry2);
labelEtage=lookup_widget(wgestion,"label_etage4");
gtk_widget_hide (labelEtage);
labelClasse=lookup_widget(wgestion,"label_classe4");
gtk_widget_hide (labelClasse);
}


void
on_GestionAcceuil_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show (wacceuil);
gtk_widget_destroy (wgestion);
}


void
on_Ajouter_Etudiant_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *entryPrenom;
GtkWidget *entryNom;
GtkWidget *entryID;
GtkWidget *entryClasse;
GtkWidget *entryPays;
GtkWidget *labelPrenom;
GtkWidget *labelNom;
GtkWidget *labelID;
GtkWidget *labelClasse;
GtkWidget *labelPays;
GtkWidget *cal1;
GtkWidget *combobox;
GtkWidget *labelCombo;
GtkWidget *existe;
GtkWidget *success;
GFile*f=NULL;
stud s;
int jj1,mm1,aa1;
int b=1;
int room;


entryPrenom=lookup_widget(wgestion,"entry_prenom");
entryNom=lookup_widget(wgestion,"entry_nom");
entryID=lookup_widget(wgestion,"entry_id");
entryClasse=lookup_widget(wgestion,"entry_classe");
entryPays=lookup_widget(wgestion,"entry_pays");

labelPrenom=lookup_widget(wgestion,"label_prenom1");
labelNom=lookup_widget(wgestion,"label_nom1");
labelID=lookup_widget(wgestion,"label_id1");
labelClasse=lookup_widget(wgestion,"label_classe1");
labelPays=lookup_widget(wgestion,"label_pays1");
labelCombo=lookup_widget(wgestion,"label_etage1");
combobox=lookup_widget(wgestion,"combobox_h");
cal1=lookup_widget(wgestion,"calendar1");
existe=lookup_widget(wgestion,"label_existant");
success=lookup_widget(wgestion,"label_succes1");

	strcpy(s.prenom,gtk_entry_get_text(GTK_ENTRY(entryPrenom) ) );
	strcpy(s.nom,gtk_entry_get_text(GTK_ENTRY(entryNom) ) );
	strcpy(s.id,gtk_entry_get_text(GTK_ENTRY(entryID) ) );
	strcpy(s.classe,gtk_entry_get_text(GTK_ENTRY(entryClasse) ) );
	strcpy(s.pays,gtk_entry_get_text(GTK_ENTRY(entryPays) ) );
	if(gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(lookup_widget(wgestion,"Homme")) )){
	strcpy(s.sexe,"Homme");
	}
	if(gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(lookup_widget(wgestion,"Femme")) )){
	strcpy(s.sexe,"Femme");
	}

gtk_widget_hide (success);

if(strcmp(s.prenom,"")==0){
		  gtk_widget_show (labelPrenom);
b=0;
}
else {
		  gtk_widget_hide(labelPrenom);
}
if(strcmp(s.nom,"")==0){
		  gtk_widget_show (labelNom);
b=0;
}
else {
		  gtk_widget_hide(labelNom);
}
if(strcmp(s.id,"")==0){
		  gtk_widget_show (labelID);
b=0;
}
else {
		  gtk_widget_hide(labelID);
}
if(strcmp(s.classe,"")==0){
		  gtk_widget_show (labelClasse);
b=0;
}
else {
		  gtk_widget_hide(labelClasse);
}
if(strcmp(s.pays,"")==0){
		  gtk_widget_show (labelPays);
b=0;
}
else {
		  gtk_widget_hide(labelPays);
}
if(gtk_combo_box_get_active (GTK_COMBO_BOX(combobox))==-1){
		  gtk_widget_show (labelCombo);
b=0;
}
else {
		  gtk_widget_hide(labelCombo);
}

if(b==1){
strcpy(s.etage,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)));
room =gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget(wgestion,"spinbutton_h")));
sprintf(s.room,"%d",room);

gtk_calendar_get_date (GTK_CALENDAR(cal1),
                       &aa1,
                       &mm1,
                       &jj1);
	sprintf(s.date,"%d/%d/%d",jj1,mm1+1,aa1);
        if(exist_etudiant(s.id)==1)
        {
				  gtk_widget_show (existe);
        }
        else {
						  gtk_widget_hide (existe);

                ajouter_etudiant(s);

						  gtk_widget_show (success);
        }
	
        GtkWidget* p=lookup_widget(wgestion,"treeview_h1");

        AfficherEtudiant(p,"students.txt");
}

}


void
on_Homme_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_Femme_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_Modifier_Etudiant_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
	stud s;

        strcpy(s.id,gtk_label_get_text(GTK_LABEL(lookup_widget(wgestion,"label_id3"))));
        strcpy(s.prenom,gtk_entry_get_text(GTK_ENTRY(lookup_widget(wgestion,"entry_prenom2"))));
        strcpy(s.nom,gtk_entry_get_text(GTK_ENTRY(lookup_widget(wgestion,"entry_nom2"))));
        strcpy(s.classe,gtk_entry_get_text(GTK_ENTRY(lookup_widget(wgestion,"entry_classe2"))));
        strcpy(s.pays,gtk_entry_get_text(GTK_ENTRY(lookup_widget(wgestion,"entry_pays2"))));


        supprimer_etudiant(s.id);
        ajouter_etudiant(s);
	
        AfficherEtudiant(lookup_widget(wgestion,"treeview_h1"),"students.txt");
		gtk_widget_show(lookup_widget(wgestion,"label_succes2"));

}


void
on_treeview_h1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	gchar *prenom;
        gchar *nom;
        gchar *id;
        gchar *classe;
        gchar *pays;
	gchar *etage;
	gchar *room;
	gchar *sexe;
	gchar *date;
        int x;
        GtkTreeModel     *model;
        GtkTreeIter iter;
        GtkWidget *p=lookup_widget(wgestion,"treeview_h1");
        GtkTreeSelection *selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {
		gtk_widget_hide(lookup_widget(wgestion,"label_succes2"));
		
                gtk_tree_model_get (model,&iter,0,&prenom,1,&nom,2,&id,3,&classe,4,&pays,5,&etage,6,&room,7,&sexe,8,&date,-1);
		
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(wgestion,"entry_prenom2")),prenom);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(wgestion,"entry_nom2")),nom);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(wgestion,"entry_classe2")),classe);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(wgestion,"entry_pays2")),pays);
                



                GtkWidget* msgID=lookup_widget(wgestion,"label_id3");
                GtkWidget* msg1=lookup_widget(wgestion,"label_modifier");
                gtk_label_set_text(GTK_LABEL(msgID),id);
                gtk_widget_show(msgID);
                gtk_widget_show(msg1);
                gtk_widget_show(lookup_widget(wgestion,"Modifier"));
                gtk_notebook_prev_page(GTK_NOTEBOOK(lookup_widget(wgestion,"notebook_h")));
        }

}


void
on_Supprimer_Etudiant_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkTreeModel     *model;
        GtkTreeSelection *selection;
        GtkTreeIter iter;
        GtkWidget* p;
        GtkWidget *label;
        gchar* id;
        label=lookup_widget(wgestion,"label_selectionner");
        p=lookup_widget(wgestion,"treeview_h1");




        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {  gtk_tree_model_get (model,&iter,0,&id,-1);
           gtk_list_store_remove(GTK_LIST_STORE(model),&iter);//supprimer la ligne du treeView

           supprimer_etudiant(id);// supprimer la ligne du fichier

           gtk_widget_hide (label);}
	else{
                gtk_widget_show (label);
        }
}


void
on_Chercher_Etudiant_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *p1;
GtkWidget *entry;
GtkWidget *entry2;
GtkWidget *labelEtage;
GtkWidget *labelClasse;
GtkWidget *nbResultat;
GtkWidget *message;
char etage[30];
char classe[30];
char chnb[30];
int nb,xe=0,xc=0;

entry=lookup_widget(wgestion,"entry_saisir_etage");
labelEtage=lookup_widget(wgestion,"label_saisir_etage");
p1=lookup_widget(wgestion,"treeview_h2");
strcpy(etage,gtk_entry_get_text(GTK_ENTRY(entry)));

entry2=lookup_widget(wgestion,"entry_saisir_classe");
labelClasse=lookup_widget(wgestion,"label_saisir_classe");
p1=lookup_widget(wgestion,"treeview_h2");
strcpy(classe,gtk_entry_get_text(GTK_ENTRY(entry2)));

if(gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(lookup_widget(wgestion,"check_etage")) )){
xe=1;}
if(gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(lookup_widget(wgestion,"check_classe")) )){
xc=1;}

nb=ChercherEtudiant(p1,"students.txt",etage,classe,xe,xc);

sprintf(chnb,"%d",nb);
nbResultat=lookup_widget(wgestion,"label_nb");
message=lookup_widget(wgestion,"label_resultat");
gtk_label_set_text(GTK_LABEL(nbResultat),chnb);

gtk_widget_show (nbResultat);
gtk_widget_show (message);
}


void
on_check_etage_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
GtkWidget *entry;
GtkWidget *labelEtage;
entry=lookup_widget(wgestion,"entry_saisir_etage");
labelEtage=lookup_widget(wgestion,"label_etage4");

if(gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(lookup_widget(wgestion,"check_etage")) )){
gtk_widget_show (entry);
gtk_widget_show (labelEtage);}

else{gtk_widget_hide (entry);
gtk_widget_hide (labelEtage);}
}


void
on_check_classe_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
GtkWidget *entry2;
GtkWidget *labelClasse;
entry2=lookup_widget(wgestion,"entry_saisir_classe");
labelClasse=lookup_widget(wgestion,"label_classe4");

if(gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(lookup_widget(wgestion,"check_classe")) )){
gtk_widget_show (entry2);
gtk_widget_show (labelClasse);}

else{gtk_widget_hide (entry2);
gtk_widget_hide (labelClasse);}
}




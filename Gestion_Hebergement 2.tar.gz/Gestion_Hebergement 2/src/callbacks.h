#include <gtk/gtk.h>
  GtkWidget *wacceuil;
  GtkWidget *wgestion;
typedef struct stud stud;
struct stud{
char prenom[30];
char nom[30];
char id[30];
char classe[30];
char pays[30];
char etage[30];
char room[10];
char sexe[30];
char date[30];
};

int x,i,j,k;

void
on_AcceuilGestion_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_GestionAcceuil_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_Ajouter_Etudiant_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_Homme_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Femme_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Modifier_Etudiant_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview_h1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_Supprimer_Etudiant_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_Chercher_Etudiant_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_check_etage_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_check_classe_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

